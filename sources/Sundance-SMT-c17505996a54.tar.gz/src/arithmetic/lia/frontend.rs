// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

//! Conversion of SMT text to parser AST and then to [LinearSystem] relations
//! and solver objects.

use std::collections;
use std::fmt::{self, Display};
use std::ops;
use std::time::Instant;

use num::Signed;
use yaspar_ir::ast::{self as smt_ast, FetchSort};
use yaspar_ir::ast::{AConstant, ATerm};
use yaspar_ir::ast::{Context, LetElim, Term, Typecheck};
use yaspar_ir::traits::Repr;
use yaspar_ir::untyped::{Command, UntypedAst};

use crate::arithmetic::lia::config::SolverConfig;
use crate::arithmetic::lia::context::ConvContext;
use crate::arithmetic::lia::equality_elim::{EqualityElimResult, Substitution, equality_eliminate};
use crate::arithmetic::lia::linear_system::{
    Addend, Constraint, LinearSystem, LinearSystemError, Rel, combine_terms_helper,
};
use crate::arithmetic::lia::lira_solver::LIRASolver;
use crate::arithmetic::lia::lra_solver::LRASolver;
use crate::arithmetic::lia::preprocess::{PreprocessResult, preprocess};
use crate::arithmetic::lia::solver_result::{
    Assignment, Conflict, SolverDecision, SolverError, SolverReturn, default_model,
};
use crate::arithmetic::lia::solver_result_api::SolverDecisionApi;
use crate::arithmetic::lia::stats::Stats;
use crate::arithmetic::lia::types::{FBig, Integer, Rational, UBig};
use crate::arithmetic::lia::variables::{Var, VarType};
use crate::debug_println;

/// Error type for conversion issues from [Term] to [Rel]
#[derive(Debug, PartialEq, Eq)]
pub struct FrontendError(pub String);

impl Display for FrontendError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl std::error::Error for FrontendError {}

impl From<String> for FrontendError {
    fn from(msg: String) -> Self {
        FrontendError(msg)
    }
}

impl From<SolverError> for FrontendError {
    fn from(err: SolverError) -> Self {
        Self(err.to_string())
    }
}

impl From<LinearSystemError> for FrontendError {
    fn from(le: LinearSystemError) -> Self {
        FrontendError(format!("error building LRA solver: {}", le))
    }
}

type FrontendResult<R> = Result<R, FrontendError>;

/// Linear expression represented by a list of [Addend]s implicitly added together
struct LinExpr(pub Vec<Addend<Rational>>);

impl LinExpr {
    /// Determine if the expression, regarded as a polynomial function, is a constant, and if
    /// so, return it.
    fn is_constant(&self) -> Option<Rational> {
        let (terms, const_sum) = Addend::separate_addends(&self.0);
        // Normalize the terms by collecting variable coefficients and filtering out
        // resulting entries with coefficient zero; e.g. x0 - x0 is constant as a
        // polynomial function
        if !combine_terms_helper(&terms).is_empty() {
            None
        } else {
            Some(const_sum)
        }
    }
}

impl ops::Add<LinExpr> for LinExpr {
    type Output = Self;

    fn add(self, rhs: LinExpr) -> Self {
        Self(self.0.into_iter().chain(rhs.0).collect())
    }
}

impl ops::Neg for LinExpr {
    type Output = Self;

    fn neg(self) -> Self {
        Self(self.0.into_iter().map(|a| -a).collect())
    }
}

impl ops::Mul<&Rational> for LinExpr {
    type Output = Self;

    fn mul(self, rhs: &Rational) -> Self {
        Self(self.0.into_iter().map(|a| a * rhs).collect())
    }
}

impl ops::Div<&Rational> for LinExpr {
    type Output = Self;

    fn div(self, rhs: &Rational) -> Self {
        Self(self.0.into_iter().map(|a| a / rhs).collect())
    }
}

// Arithmetic operator symbols for matching
const PLUS_SYMBOL: &str = "+";
const NEG_SYMBOL: &str = "-";
const MULT_SYMBOL: &str = "*";
const REAL_DIV_SYMBOL: &str = "/";
const INT_DIV_SYMBOL: &str = "div";
const INT_MOD_SYMBOL: &str = "mod";
const TO_REAL_SYMBOL: &str = "to_real";
// Note: to_int and is_int are not supported

// Arithmetic relation symbols for matching
const EQ_SYMBOL: &str = "=";
const LE_SYMBOL: &str = "<=";
const LT_SYMBOL: &str = "<";
const GE_SYMBOL: &str = ">=";
const GT_SYMBOL: &str = ">";

// Sort names
// const BOOL_SORT: &str = "Bool";

/// Convert a term to a linear expression represented as a vector of [Addend]s.
///
/// This function takes an SMT term representing a linear-affine expression and
/// converts it to a vector of [Addend]s, suitable for building [Rel]ations and
/// for use in the linear system solver.
///
/// # Arguments
/// * `term` - The SMT term to convert to a linear expression
///
/// Note: [Term] is an `HConsed<RTerm>`, `RTerm` is a wrapper around `alg::raw::Term<...>`
///
/// # Returns
/// A `Result` containing either:
/// - `Ok(Vec<Mon<Rational>>)` - Vector of monomials representing the linear expression
/// - `Err(String)` - Error message if the conversion fails
///
/// TODO: add source metadata to conversion errors
/// TODO: support left-associating -, +, *, /
fn convert_linear_term(ctx: &mut ConvContext, term: &Term) -> FrontendResult<LinExpr> {
    match term.get().repr() {
        ATerm::Constant(c, _) => Ok(LinExpr(vec![c.convert_constant()?])),
        // handle variables
        ATerm::Global(smt_ast::alg::QualifiedIdentifier(id, _), sort) => {
            let name = id.symbol.get();
            let var_typ = match sort {
                Some(hs) => {
                    let rsort = hs.get();
                    let name = rsort.sort_name().get().as_str();
                    let ind = &rsort.1;
                    debug_assert!(ind.is_empty()); // expect no sort parameters
                    if name == "Real" {
                        VarType::Real
                    } else if name == "Int" {
                        VarType::Int
                    } else {
                        unreachable!() // unreachable assuming type checking and logic is set correctly
                    }
                }
                None => {
                    panic!("no sort information for {name}")
                }
            };
            let var = ctx.allocate_var_term(name, var_typ, term.clone());

            Ok(LinExpr(vec![Addend::term(Rational::ONE, var)]))
        }
        // handle +, *, -, /
        ATerm::App(smt_ast::alg::QualifiedIdentifier(op_id, _op_sort), args, app_sort) => {
            let op_name = op_id.symbol.get();
            match op_name.as_str() {
                PLUS_SYMBOL => {
                    let expr_args = args
                        .iter()
                        .map(|a| convert_linear_term(ctx, a).map(|l| l.0))
                        .collect::<Result<Vec<_>, _>>()?;
                    Ok(LinExpr(expr_args.into_iter().flatten().collect())) // flattening implicitly adds the terms in our rep'n
                }
                NEG_SYMBOL => {
                    debug_assert!(!args.is_empty(), "expected negation to have arguments");
                    let mut expr_args: Vec<LinExpr> = args
                        .iter()
                        .map(|a| convert_linear_term(ctx, a))
                        .collect::<Result<Vec<_>, _>>()?;
                    if expr_args.len() == 1 {
                        // (- a) := -a
                        Ok(-expr_args.remove(0))
                    } else {
                        // (- a b c) := (a - b) - c = a + (-(b + c))
                        let first = expr_args.swap_remove(0);
                        let subtractant =
                            -LinExpr(expr_args.into_iter().flat_map(|l| l.0).collect());
                        Ok(first + subtractant)
                    }
                }
                MULT_SYMBOL => {
                    debug_assert!(
                        args.len() == 2,
                        "chainable multiplication ops are not supported"
                    );
                    let e1 = convert_linear_term(ctx, &args[0])?;
                    let e2 = convert_linear_term(ctx, &args[1])?;
                    if let Some(c) = e1.is_constant() {
                        Ok(e2 * &c)
                    } else if let Some(c) = e2.is_constant() {
                        Ok(e1 * &c)
                    } else {
                        Err(FrontendError(
                            "non-linear multiplication is not supported".to_string(),
                        ))
                    }
                }
                REAL_DIV_SYMBOL => {
                    debug_assert!(args.len() == 2, "chainable division is not supported");
                    let e1 = convert_linear_term(ctx, &args[0])?;
                    let e2 = convert_linear_term(ctx, &args[1])?;
                    // e1 / e2 is linear iff. e2 is constant
                    if let Some(c) = e2.is_constant() {
                        Ok(e1 / &c)
                    } else {
                        Err(FrontendError(
                            "non-linear division is not supported".to_string(),
                        ))
                    }
                }
                INT_DIV_SYMBOL => {
                    // SMT-LIB integer division (Euclidean): (div e n) = q
                    // where e = n * q + r, 0 <= r < |n|
                    debug_assert!(args.len() == 2, "chainable division is not supported");
                    // If this term was already converted, its constraints are already in
                    // the context; just reuse the quotient variable.
                    if let Some(q) = ctx.get_term(term.clone()) {
                        return Ok(LinExpr(vec![Addend::term(Rational::ONE, q)]));
                    }
                    let e1 = convert_linear_term(ctx, &args[0])?;
                    let e2 = convert_linear_term(ctx, &args[1])?;
                    if let Some(n) = e2.is_constant() {
                        if n.is_zero() {
                            return Err(FrontendError("integer division by zero".to_string()));
                        }
                        // Introduce fresh integer variable q for the quotient,
                        // associated with the div term for model reporting
                        let q = ctx.allocate_term(term.clone(), None, app_sort.clone());
                        // Constraint 1: e - n*q >= 0  (i.e., remainder >= 0)
                        let rel_ge = Rel::from_addends_lhs_rhs(
                            e1.0.iter()
                                .cloned()
                                .chain(std::iter::once(Addend::term(-n.clone(), q)))
                                .collect(),
                            Constraint::Ge,
                            vec![Addend::Constant(Rational::ZERO)],
                        );
                        let slack_ge = ctx.allocate_var(
                            &format!("$div_slack_ge_{}", ctx.num_variables()),
                            VarType::Real,
                        );
                        ctx.push_relation(rel_ge, slack_ge);
                        // Constraint 2: e - n*q <= |n| - 1  (i.e., remainder < |n|)
                        let rel_le = Rel::from_addends_lhs_rhs(
                            e1.0.iter()
                                .cloned()
                                .chain(std::iter::once(Addend::term(-n.clone(), q)))
                                .collect(),
                            Constraint::Le,
                            vec![Addend::Constant(n.abs() - Rational::ONE)],
                        );
                        let slack_le = ctx.allocate_var(
                            &format!("$div_slack_le_{}", ctx.num_variables()),
                            VarType::Real,
                        );
                        ctx.push_relation(rel_le, slack_le);
                        // Return q as the result expression
                        Ok(LinExpr(vec![Addend::term(Rational::ONE, q)]))
                    } else {
                        Err(FrontendError(
                            "non-linear integer division is not supported".to_string(),
                        ))
                    }
                }
                INT_MOD_SYMBOL => {
                    // SMT-LIB integer modulus (Euclidean): (mod e n) = r
                    // where e = n * q + r, 0 <= r < |n|
                    debug_assert!(args.len() == 2, "chainable modulus is not supported");
                    // If this term was already converted, its constraints are already in
                    // the context; just reuse the remainder variable.
                    if let Some(r) = ctx.get_term(term.clone()) {
                        return Ok(LinExpr(vec![Addend::term(Rational::ONE, r)]));
                    }
                    let e1 = convert_linear_term(ctx, &args[0])?;
                    let e2 = convert_linear_term(ctx, &args[1])?;
                    if let Some(n) = e2.is_constant() {
                        if n.is_zero() {
                            return Err(FrontendError("integer modulus by zero".to_string()));
                        }
                        // The remainder variable is associated with the mod term itself, so
                        // that it is reported in models; the quotient is auxiliary.
                        let r = ctx.allocate_term(term.clone(), None, app_sort.clone());
                        let q = ctx.allocate_var(&ctx.fresh_name("$mod_quotient"), VarType::Int);
                        // Constraint 1: e - n*q - r = 0  (i.e., e = n*q + r)
                        let rel_eq = Rel::from_addends_lhs_rhs(
                            e1.0.iter()
                                .cloned()
                                .chain([
                                    Addend::term(-n.clone(), q),
                                    Addend::term(-Rational::ONE, r),
                                ])
                                .collect(),
                            Constraint::Eq,
                            vec![Addend::Constant(Rational::ZERO)],
                        );
                        let slack_eq =
                            ctx.allocate_var(&ctx.fresh_name("$mod_slack_eq"), VarType::Real);
                        ctx.push_relation(rel_eq, slack_eq);
                        // Constraint 2: r >= 0
                        let rel_ge = Rel::from_addends_lhs_rhs(
                            vec![Addend::term(Rational::ONE, r)],
                            Constraint::Ge,
                            vec![Addend::Constant(Rational::ZERO)],
                        );
                        let slack_ge =
                            ctx.allocate_var(&ctx.fresh_name("$mod_slack_ge"), VarType::Real);
                        ctx.push_relation(rel_ge, slack_ge);
                        // Constraint 3: r <= |n| - 1  (i.e., r < |n|)
                        let rel_le = Rel::from_addends_lhs_rhs(
                            vec![Addend::term(Rational::ONE, r)],
                            Constraint::Le,
                            vec![Addend::Constant(n.abs() - Rational::ONE)],
                        );
                        let slack_le =
                            ctx.allocate_var(&ctx.fresh_name("$mod_slack_le"), VarType::Real);
                        ctx.push_relation(rel_le, slack_le);
                        // Return r as the result expression
                        Ok(LinExpr(vec![Addend::term(Rational::ONE, r)]))
                    } else {
                        Err(FrontendError(
                            "non-linear integer modulus is not supported".to_string(),
                        ))
                    }
                }
                TO_REAL_SYMBOL => {
                    // the types of non-variable terms are effectively erased, so
                    // to_real is a no-op. As far as the solver is concerned, variables
                    // have type constraints, but all arithmetic is rational.
                    Ok(convert_linear_term(ctx, &args[0])?)
                }
                _op => {
                    // method to create a variable for an uninterpreted function based on its type
                    let var_t = ctx.allocate_term(term.clone(), None, app_sort.clone());
                    Ok(LinExpr(vec![Addend::term(Rational::ONE, var_t)])) // Integer one as rational
                }
            }
        }

        ATerm::Ite(_, t1, _) => {
            // we are treating ite as an uninterpreted function
            // don't know the sort so letting it be 0
            let sort = t1.get_sort(&mut Context::new());
            let var_t = ctx.allocate_term(term.clone(), None, Some(sort));
            Ok(LinExpr(vec![Addend::term(Rational::ONE, var_t)])) // Integer one as rational
        }

        // everything else is unreachable for QF_LIA, QF_LRA _terms_
        _ => unreachable!(),
    }
}

/// Generic constant converter allows us to ignore the flexible string type parameter
trait NumConstantConverter {
    fn convert_constant(&self) -> Result<Addend<Rational>, FrontendError>;
}

impl<Str> NumConstantConverter for AConstant<Str> {
    /// Convert a constant term to an [Addend]
    fn convert_constant(&self) -> Result<Addend<Rational>, FrontendError> {
        match self {
            // note: numerals are non-negative
            // TODO: only possible numeral conversion is str -> str :(
            AConstant::Numeral(i) => Ok(Addend::Constant(Rational::from(i.clone()))),
            AConstant::Decimal(d) => Ok(Addend::Constant(convert_dbig(d)?)),
            _ => unreachable!(),
        }
    }
}

/// Convert an high precision floating point number into an arbitrary precision rational; the operation
/// is lossless.
fn convert_dbig(
    d: &FBig<crate::arithmetic::lia::types::float::round::mode::HalfAway, 10>,
) -> FrontendResult<Rational> {
    // express d = significant * 10^exponent
    let drepr = d.repr();
    let exponent = drepr.exponent();
    if exponent >= 0 {
        Ok(Rational::from(drepr.significand().clone())
            * Integer::from(10u32).pow(exponent as usize))
    } else {
        let uexp = usize::try_from(exponent.abs()).map_err(|_| {
            FrontendError(format!(
                "convert_dbig: failed to convert negative exponent: {exponent}"
            ))
        })?;
        Ok(Rational::from_parts(
            drepr.significand().clone(),
            UBig::from(10u32).pow(uexp),
        ))
    }
}

/// Try to convert a relation string into a [Constraint]
fn convert_constraint(symbol: &str) -> FrontendResult<Constraint> {
    match symbol {
        EQ_SYMBOL => Ok(Constraint::Eq),
        LE_SYMBOL => Ok(Constraint::Le),
        LT_SYMBOL => Ok(Constraint::Lt),
        GE_SYMBOL => Ok(Constraint::Ge),
        GT_SYMBOL => Ok(Constraint::Gt),
        _ => Err(FrontendError(format!(
            "expected relation symbol {:?}",
            symbol
        ))),
    }
}
/// Convert a term to a linear relation.
///
/// This function takes an SMT term representing an arithmetic relation (=, >=, ...)
/// and converts it to a linear relation that can be used in the linear system solver.
///
/// Return type has the Option to return None when the term in question can be ignored, e.g.
/// boolean literals from an implicant.
fn convert_relation(ctx: &mut ConvContext, term: &Term) -> FrontendResult<Option<Rel<Rational>>> {
    match term.repr() {
        // handle =, >=, >, <=, <
        ATerm::App(smt_ast::alg::QualifiedIdentifier(rel_id, _op_sort), args, _app_sort) => {
            if *rel_id.symbol != ">="
                && *rel_id.symbol != ">"
                && *rel_id.symbol != "<="
                && *rel_id.symbol != "<"
            {
                return Ok(None);
            }
            // TODO: support left-assoc (in)equality?
            debug_assert!(
                args.len() == 2,
                "left-associative form of (in)equality is not supported"
            );
            let lhs = convert_linear_term(ctx, &args[0])?;
            let rhs = convert_linear_term(ctx, &args[1])?;
            let rel_name = rel_id.symbol.get().as_str();
            let constraint = convert_constraint(rel_name)?;
            Ok(Some(Rel::from_addends_lhs_rhs(lhs.0, constraint, rhs.0)))
        }
        // handle term identifiers
        ATerm::Global(smt_ast::alg::QualifiedIdentifier(_id, _sort), _) => {
            // Nothing to convert
            Ok(None)
        }
        // Equality is represented above the literal level
        ATerm::Eq(t1, t2) => {
            if (t1.get_sort(&mut Context::new()).sort_name().as_str() != "Real"
                && t1.get_sort(&mut Context::new()).sort_name().as_str() != "Int")
                || (t2.get_sort(&mut Context::new()).sort_name().as_str() != "Real"
                    && t2.get_sort(&mut Context::new()).sort_name().as_str() != "Int")
            {
                return Ok(None);
            }
            let lhs = convert_linear_term(ctx, t1)?;
            let rhs = convert_linear_term(ctx, t2)?;
            Ok(Some(Rel::from_addends_lhs_rhs(
                lhs.0,
                Constraint::Eq,
                rhs.0,
            )))
        }
        ATerm::Not(t) => {
            // TODO: Not handling is done identically at two levels
            if let Some(rel) = convert_relation(ctx, t)? {
                Ok(rel.negate())
            } else {
                Ok(None)
            }
        }
        _ => Ok(None), // Err(FrontendError(format!("expected relation term {:?}", term))),
    }
}

fn convert_arith_literal(
    ctx: &mut ConvContext,
    term: &Term,
) -> FrontendResult<Option<Rel<Rational>>> {
    match term.get().repr() {
        // ignore annotations
        ATerm::Annotated(t, _) => convert_relation(ctx, t),
        // handle arithmetic relations
        ATerm::App(..) | ATerm::Eq(..) => convert_relation(ctx, term),
        // handle negated literals
        ATerm::Not(t) => {
            if let Some(rel) = convert_relation(ctx, t)? {
                Ok(rel.negate())
            } else {
                Ok(None)
            }
        }
        _ => Ok(None),
        // Err(FrontendError(format!(
        //     "expected arithmetic literal, but got: {:?}",
        //     term
        // ))),
    }
}

/// Type-check and eliminate let bindings from all assertion commands in a script.
///
/// This function processes a vector of parser commands, converting them to the internal
/// AST representation, type-checking them, and eliminating let bindings. Only assertion
/// commands are processed and returned as terms. The logic is also validated.
///
/// # Arguments
/// * `context` - Mutable reference to the SMT context for type checking and conversion
/// * `cmds` - Vector of untyped AST commands to process
///
/// # Returns
/// A vector of terms representing the assertions with let bindings eliminated
fn tc_let_elim_all(context: &mut Context, cmds: Vec<Command>) -> FrontendResult<Vec<Term>> {
    let mut ret = vec![];
    for cmd in &cmds {
        let cmd = cmd
            .type_check(context)
            .map_err(|e| FrontendError(format!("type error: command '{cmd}', error '{e}'")))?;
        match cmd.repr() {
            // collect assertions to return
            smt_ast::ACommand::Assert(t) => {
                ret.push(t.let_elim(context));
            }
            // ensure logic is correct
            smt_ast::ACommand::SetLogic(hlogic) => {
                let logic = hlogic.get().as_str();
                if !(logic == "QF_LRA" || logic == "QF_LIA" || logic == "QF_LIRA") {
                    return Err(FrontendError(format!("unsupported logic: {}", logic)));
                }
            }
            _ => continue,
        }
    }
    Ok(ret)
}

/// Parse an SMT script into a vector of assertion terms
fn smt_to_terms(smt: &str) -> FrontendResult<Vec<Term>> {
    let cmds = UntypedAst
        .parse_script_str(smt)
        .map_err(|e| e.to_string())?;
    let mut context = Context::new();
    tc_let_elim_all(&mut context, cmds)
}

/// Parse an SMT script and return a list of arithmetic relations
///
/// The SMT script is required to have logic QF_LRA/LIA and be a top-level conjunction of
/// arithmetic literals. Disequality is currently not handled; ideally it should be
/// pre-processed away upstream.
pub fn convert_smt(smt_input: &str) -> FrontendResult<ConvContext> {
    let terms = smt_to_terms(smt_input)?;
    debug_println!(
        15,
        0,
        "lia::frontend: number of converted terms = {}",
        terms.len()
    );
    convert_terms(&terms)
}

fn convert_terms(terms: &[Term]) -> FrontendResult<ConvContext> {
    let mut ctx = ConvContext::new();
    for t in terms {
        if let Some(r) = convert_arith_literal(&mut ctx, t)? {
            // Allocate a slack variable associated with the term
            // Note: cloning `t` is cheap; it's a uid + arc ref
            let slack_t = ctx.allocate_term(t.clone(), None, None);
            ctx.push_relation(r, slack_t);
        }
    }
    Ok(ctx)
}

/// Parse an SMT script and build a QF_LRA solver without preprocessing
pub fn smt_to_lra_solver(smt_input: &str, config: &SolverConfig) -> FrontendResult<LRASolver> {
    let ctx = convert_smt(smt_input)?;
    Ok(LinearSystem::new(ctx).to_lra_solver(true, config)?)
}

/// Top-level arithmetic solving function
///
/// This provides solving a system of linear (in)equalities over the rationals as a single function
/// call from SMT-LIB text as input.
pub fn solve_smtlib(smt_input: &str, config: &SolverConfig) -> FrontendResult<SolverDecisionApi> {
    let ctx = convert_smt(smt_input)?;
    solve_with_context(ctx, config)
}

/// Top-level mixed-integer arithmetic solver
///
/// This version accepts a list of arithmetic literals and returns SAT/UNSAT/UNKNOW
/// as usual. SAT comes with a satisfying assignment and UNSAT comes with a conflict
/// set which is guaranteed to be a subset of the input literals.
pub fn solve(arith_literals: &[Term], config: &SolverConfig) -> FrontendResult<SolverDecisionApi> {
    // The context is used to construct a solver below, but also to report conflicts
    // and assignments to the outside in terms of [Term]s rather than internal variables.
    // This value is consumed below, but some of the mappings are cloned for reporting.
    let ctx = convert_terms(arith_literals)?;
    solve_with_context(ctx, config)
}

fn solve_with_context(
    mut ctx: ConvContext,
    config: &SolverConfig,
) -> FrontendResult<SolverDecisionApi> {
    let (_, var_term_map) = ctx.get_term_var_maps(); // this is a clone
    let ret = solve_ctx_raw(&mut ctx, config)?;
    // TODO: frontend::solve_with_context: return stats through SolverDecisionApi
    Ok(SolverDecisionApi::from_solver_decision(
        &var_term_map,
        ret.decision,
    )?)
}

/// Recover eliminated variables' values by applying substitutions in reverse order.
fn back_substitute_model(model: &mut Assignment<Var>, substitutions: &[Substitution]) {
    for subst in substitutions.iter().rev() {
        match subst {
            Substitution::Constant { target, value } => {
                model.insert(*target, value.clone());
            }
            Substitution::Variable {
                target,
                replacement,
            } => {
                let val = value_or_zero(model, *replacement);
                model.insert(*target, val);
            }
            Substitution::Affine {
                target,
                replacement,
                offset,
            } => {
                let val = value_or_zero(model, *replacement);
                model.insert(*target, val + offset);
            }
        }
    }
}

/// The model value of `var`. A replacement variable that no remaining relation
/// mentions is unconstrained, so the solver's model has no value for it; give it 0
/// (and record it, so every variable eliminated in its favor gets a value too).
/// Without this, those variables were missing from the model, and the propagator's
/// Nelson-Oppen probe never saw that, e.g., `x` and `(+ 0 x)` are equal.
fn value_or_zero(model: &mut Assignment<Var>, var: Var) -> Rational {
    if let Some(value) = model.get(&var) {
        return value.clone();
    }
    model.insert(var, Rational::ZERO);
    Rational::ZERO
}

/// Run the solver given the provided context and return the resulting SolverDecision.
pub fn solve_ctx_raw(ctx: &mut ConvContext, config: &SolverConfig) -> FrontendResult<SolverReturn> {
    // Phase 1: normalize, remove trivial-sat, detect trivial-unsat
    let result = preprocess(ctx);
    debug_println!(
        21,
        0,
        "lia::frontend: num_variables = {}, num_relations = {}",
        ctx.num_variables(),
        ctx.num_relations()
    );
    match result {
        PreprocessResult::TriviallySat => {
            return Ok(SolverReturn::new(
                SolverDecision::FEASIBLE(default_model(ctx.get_all_vars())),
                Stats::new(),
            ));
        }
        PreprocessResult::TriviallyUnsat(v) => {
            let mut conflict = collections::BTreeSet::new();
            conflict.insert(v);
            return Ok(SolverReturn::new(
                SolverDecision::INFEASIBLE(Conflict::from_set(conflict)),
                Stats::new(),
            ));
        }
        PreprocessResult::Unknown => {}
    }

    // Phase 2: equality elimination
    let elim_result = equality_eliminate(ctx);
    debug_println!(
        21,
        0,
        "lia::frontend: after equality_elim: num_relations = {}, num_substitutions = {}",
        ctx.num_relations(),
        ctx.get_substitutions().len()
    );
    match elim_result {
        EqualityElimResult::TriviallySat => {
            let mut model = default_model(ctx.get_all_vars());
            back_substitute_model(&mut model, ctx.get_substitutions());
            return Ok(SolverReturn::new(
                SolverDecision::FEASIBLE(model),
                Stats::new(),
            ));
        }
        EqualityElimResult::TriviallyUnsat(conflict) => {
            return Ok(SolverReturn::new(
                SolverDecision::INFEASIBLE(conflict),
                Stats::new(),
            ));
        }
        EqualityElimResult::Unknown => {}
    }

    // Substitution can produce relations that are no longer tight on the integer grid (e.g.
    // `x − y > −1` with no strict counterpart over the integers); tighten them again. Each
    // relation keeps its slack, so conflict explanation and provenance are unaffected. A
    // relation with no integer solution is a conflict on its own (plus the equalities folded
    // into it).
    let mut integer_infeasible = None;
    for (rel, var) in ctx.get_relations_mut() {
        rel.normalize();
        if rel.tighten_integral() {
            integer_infeasible = Some(*var);
            break;
        }
    }
    if let Some(var) = integer_infeasible {
        let mut conflict = collections::BTreeSet::new();
        conflict.insert(var);
        if let Some(prov) = ctx.get_provenance(&var) {
            conflict.extend(prov.iter().copied());
        }
        return Ok(SolverReturn::new(
            SolverDecision::INFEASIBLE(Conflict::from_set(conflict)),
            Stats::new(),
        ));
    }

    // Phase 3: build system and solve
    let sys = LinearSystem::new(ctx.clone());
    let lra_solver = sys
        .to_lra_solver(true, config)
        .map_err(|e| FrontendError(format!("error building lra_solver: {}", e)))?;
    let mut lira_solver = LIRASolver::new(lra_solver, config.clone());
    debug_println!(25, 0, "lia::frontend::solve_ctx_raw: Starting LIRA solver");
    let start = Instant::now();
    let mut ret = lira_solver
        .solve()
        .map_err(|e| FrontendError(format!("error solving: {}", e)))?;
    let duration = start.elapsed();
    debug_println!(
        25,
        4,
        "lia::frontend::solve_ctx_raw: LIRA solver finished, duration: {duration:?}"
    );

    // Post-process solver result with equality elimination information
    match ret.decision {
        SolverDecision::FEASIBLE(ref mut model) => {
            back_substitute_model(model, ctx.get_substitutions());
        }
        SolverDecision::INFEASIBLE(ref mut conflict) => {
            let vars_to_expand: Vec<Var> = conflict.iter().copied().collect();
            for var in vars_to_expand {
                if let Some(prov) = ctx.get_provenance(&var) {
                    for src in prov {
                        conflict.insert(*src);
                    }
                }
            }
        }
        SolverDecision::UNKNOWN => {}
    }

    Ok(ret)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::arithmetic::lia::config::SolverConfig;
    use crate::arithmetic::lia::frontend::{convert_smt, smt_to_lra_solver, solve_smtlib};
    use crate::arithmetic::lia::preprocess::{PreprocessResult, preprocess};
    use crate::arithmetic::lia::solver_result::SolverDecision;
    use crate::arithmetic::lia::solver_result_api::SolverDecisionApi;
    use crate::arithmetic::lia::types::{DBig, rbig};
    use crate::arithmetic::lia::variables::Var;
    use std::str::FromStr;

    // A sanity check for `convert_dbig`
    #[test]
    fn fbig_digits() -> Result<(), dashu::base::ParseError> {
        let d = DBig::from_str("1.00234")?; // 100234 * 10^-5
        let expected_r = Rational::ONE + rbig!(234 / 100_000);
        assert_eq!(
            convert_dbig(&d).expect("failed to convert dbig"),
            expected_r
        );
        Ok(())
    }

    #[test]
    fn test_convert_smt_linear_real() {
        // Create a simple SMT-LIB script with linear real arithmetic
        let smt = r#"
            (set-logic QF_LRA)
            (declare-fun x0 () Real)
            (declare-fun x1 () Real)
            (assert (>= (+ x0 (* 2 x1)) 3))
            (assert (<= x1 1))
        "#;

        // Convert SMT script to relations
        let ctx = convert_smt(smt).unwrap();

        // Verify we got 2 relations
        assert_eq!(ctx.num_relations(), 2);

        // First relation: x0 + 2x1 >= 3
        let expected_rel1 = Rel::from_addends_lhs_rhs(
            vec![
                Addend::term(Rational::ONE, Var::real(0)),
                Addend::term(rbig!(2), Var::real(1)),
            ],
            Constraint::Ge,
            vec![Addend::constant(rbig!(3))],
        );

        // Second relation: x1 <= 1
        let expected_rel2 = Rel::from_addends_lhs_rhs(
            vec![Addend::term(Rational::ONE, Var::real(1))],
            Constraint::Le,
            vec![Addend::constant(rbig!(1))],
        );

        // Verify the relations match what we expect
        let rels: Vec<&Rel<Rational>> = ctx.get_relations().map(|(r, _)| r).collect();
        assert!(rels[0].equivalent(&expected_rel1));
        assert!(rels[1].equivalent(&expected_rel2));
    }

    #[test]
    fn test_convert_smt_linear_real_with_negation() {
        // Create a simple SMT-LIB script with linear real arithmetic with a negated literal
        let smt = r#"
            (set-logic QF_LRA)
            (declare-fun x0 () Real)
            (assert (not (<= x0 0)))
        "#;
        let ctx = convert_smt(smt).unwrap();
        assert_eq!(ctx.num_relations(), 1);
        // relation: x0 > 0
        let expected_rel = Rel::from_addends_lhs_rhs(
            vec![Addend::term(Rational::ONE, Var::real(0))],
            Constraint::Gt,
            vec![Addend::constant(rbig!(0))],
        );
        let (rel, _) = ctx.get_relations().next().unwrap();
        assert!(rel.equivalent(&expected_rel));
    }

    #[test]
    fn test_convert_smt_var_types_converted() {
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (declare-fun y () Int)
            (assert (<= x y))
        "#;
        let ctx = convert_smt(smt).unwrap();
        let expected_rel = Rel::from_addends_lhs_rhs(
            vec![
                Addend::term(Rational::ONE, Var::int(0)),
                Addend::term(-Rational::ONE, Var::int(1)),
            ],
            Constraint::Le,
            vec![Addend::constant(rbig!(0))],
        );
        let (rel, _) = ctx.get_relations().next().unwrap();
        assert!(rel.equivalent(&expected_rel));
    }

    #[test]
    fn test_constant_integer_division() {
        // (div x 2) introduces a fresh quotient variable q with Euclidean constraints:
        //   x - 2q >= 0 and x - 2q <= 1
        // The equality (= 1 (div x 2)) means q = 1
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (div x 2)))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // Should produce 3 relations: the equality (1 = q) and two Euclidean constraints
        assert_eq!(ctx.num_relations(), 3);

        // Test a non-linear division
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (div 3 x)))
        "#;
        assert!(convert_smt(smt).is_err());

        // Test division by a constant polynomial
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (declare-fun y () Int)
            (assert (<= 1 (div x (+ 5 (+ y (- y))))))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // Should produce 3 relations: the inequality (1 <= q) and two Euclidean constraints
        assert_eq!(ctx.num_relations(), 3);
    }

    /// A repeated `div` term must not push its Euclidean constraints twice.
    ///
    /// Before the fix, the second occurrence of `(div x 2)` reused the existing
    /// quotient variable but still pushed a second, redundant copy of both
    /// Euclidean constraints (6 relations instead of 4), each with its own fresh
    /// slack variable — extra tableau rows and slack columns for no added
    /// information.
    #[test]
    fn test_repeated_div_term_shares_constraints() {
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (div x 2)))
            (assert (<= (div x 2) 1))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // 2 input relations + 2 Euclidean constraints from the single (div x 2) term
        assert_eq!(ctx.num_relations(), 4);
        // Every relation must own a distinct slack variable
        let slacks: Vec<Var> = ctx.get_relations().map(|(_, v)| *v).collect();
        let unique: std::collections::BTreeSet<Var> = slacks.iter().copied().collect();
        assert_eq!(
            slacks.len(),
            unique.len(),
            "relations must not share slack variables: {slacks:?}"
        );
    }

    #[test]
    fn test_constant_integer_modulus() {
        // (mod x 2) introduces a fresh remainder variable r and quotient q with
        // Euclidean constraints: x - 2q - r = 0, r >= 0 and r <= 1
        // The equality (= 1 (mod x 2)) means r = 1
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (mod x 2)))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // Should produce 4 relations: the equality (1 = r) and three Euclidean constraints
        assert_eq!(ctx.num_relations(), 4);

        // Test a non-linear modulus
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (mod 3 x)))
        "#;
        assert!(convert_smt(smt).is_err());

        // Test modulus by a constant polynomial
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (declare-fun y () Int)
            (assert (<= 1 (mod x (+ 5 (+ y (- y))))))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // Should produce 4 relations: the inequality (1 <= r) and three Euclidean constraints
        assert_eq!(ctx.num_relations(), 4);
    }

    /// A repeated `mod` term must not push its Euclidean constraints twice.
    #[test]
    fn test_repeated_mod_term_shares_constraints() {
        let smt = r#"
            (set-logic QF_LIA)
            (declare-fun x () Int)
            (assert (= 1 (mod x 2)))
            (assert (<= (mod x 2) 1))
        "#;
        let ctx = convert_smt(smt).unwrap();
        // 2 input relations + 3 Euclidean constraints from the single (mod x 2) term
        assert_eq!(ctx.num_relations(), 5);
        // Every relation must own a distinct slack variable
        let slacks: Vec<Var> = ctx.get_relations().map(|(_, v)| *v).collect();
        let unique: std::collections::BTreeSet<Var> = slacks.iter().copied().collect();
        assert_eq!(
            slacks.len(),
            unique.len(),
            "relations must not share slack variables: {slacks:?}"
        );
    }

    /// `(mod x n)` follows SMT-LIB Euclidean semantics: the remainder is
    /// non-negative and strictly below `|n|`.
    #[test]
    fn test_int_mod_euclidean_semantics_sat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const x Int)
(assert (= x 7))
(assert (= (mod x 3) 1))  ; 7 = 3*2 + 1
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));
    }

    /// The remainder of `(mod 7 3)` is uniquely 1; any other value is infeasible.
    #[test]
    fn test_int_mod_constant_unsat_wrong_remainder() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (mod 7 3)))
(assert (= r 2))  ; 7 - 3q = 2 has no integer solution q
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)));
    }

    /// Euclidean modulus of a negative numerator is non-negative:
    /// `(mod (- 1) 3)`: -1 = 3*(-1) + 2, so the remainder is 2 (not -1).
    #[test]
    fn test_int_mod_negative_numerator_nonnegative() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (mod (- 1) 3)))
(assert (= r 2))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));
    }

    /// Euclidean modulus by a negative denominator is still non-negative and
    /// bounded by `|n|`: `(mod 9 (- 2))`: 9 = (-2)*(-4) + 1, so the remainder is 1.
    #[test]
    fn test_int_mod_negative_denominator_nonnegative() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (mod 9 (- 2))))
(assert (= r 1))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));
    }

    /// A negative remainder is never a solution, even though `9 = (-2)*(-5) + (-1)`
    /// holds over the integers.
    #[test]
    fn test_int_mod_negative_remainder_unsat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (mod 9 (- 2))))
(assert (= r (- 1)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)));
    }

    #[test]
    fn test_mod_zero_by_c() {
        // Modulus by a non-constant denominator is rejected, mirroring `div`
        let smt_input = r#"
(declare-fun C () Int)
(assert (= C 1))
(assert (= 1 (mod 0 C)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default());
        assert!(result.is_err_and(
            |e| e == FrontendError("non-linear integer modulus is not supported".to_string())
        ));
    }

    // ---------------------------------------------------------------------
    // ---      Tests ported from LIA frontend integration tests         ---
    // ---------------------------------------------------------------------

    #[test]
    fn test_top_level_solve_smtlib() {
        let smt = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(assert (not (<= x0 0)))
(check-sat)
    "#;
        assert!(matches!(
            solve_smtlib(smt, &SolverConfig::default()).unwrap(),
            SolverDecisionApi::FEASIBLE(_)
        ));
    }

    /// Test that trivially satisfiable relations are removed during preprocessing
    ///
    /// System:
    ///   x0 + x1 <= 5       (non-trivial relation)
    ///   0 <= 5             (trivially satisfiable relation)
    ///   x0 - x1 >= -2      (non-trivial relation)
    ///   x0 - x0 <= 0       (trivially satisfiable relation)
    ///
    /// The resulting system should only have 2 relations, as the trivially satisfiable
    /// relation "0 <= 5" should be removed during normalization.
    #[test]
    fn test_trivially_sat_relation_removal() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(declare-fun x1 () Real)
(assert (<= (+ x0 x1) 5))
(assert (<= 0 5))
(assert (>= (+ x0 (- x1)) (- 2)))
(assert (<= (+ x0 (- x0)) 0))
(check-sat)
    "#;
        let mut ctx = convert_smt(smt_input).expect("parsing relations failed?");
        if let PreprocessResult::Unknown = preprocess(&mut ctx) {
            assert_eq!(ctx.num_relations(), 2);
        } else {
            unreachable!()
        }

        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));
    }

    /// Test that trivially satisfiable relations are removed during preprocessing
    ///
    /// System:
    ///   0 <= 5             (trivially satisfiable relation)
    ///   x0 - x0 <= 0       (trivially satisfiable relation)
    ///
    /// The resulting system is trivially satisfiable.
    #[test]
    fn test_trivially_sat() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(declare-fun x1 () Real)
(assert (<= 0 5))
(assert (<= (+ x0 (- x0)) 0))
(check-sat)
    "#;
        let mut ctx = convert_smt(smt_input).expect("parsing relations failed");
        assert!(matches!(
            preprocess(&mut ctx),
            PreprocessResult::TriviallySat
        ));
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));
    }

    /// Test that trivially contradictory constraints result in a trivially infeasible
    /// linear system.
    ///
    /// System:
    ///   x0 - x0 > 1        (trivially unsat)
    ///
    /// The resulting system should only have 1 relation: the normalized form of
    /// the second relation.
    #[test]
    fn test_frontend_trivially_unsat_relation_preprocessing() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(assert (> (+ x0 (- x0)) 2))
(check-sat)
    "#;
        let mut ctx = convert_smt(smt_input).expect("parsing relations failed");
        assert!(matches!(
            preprocess(&mut ctx),
            PreprocessResult::TriviallyUnsat(_)
        ));
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)));
    }

    #[test]
    fn test_smt_to_lra_solver() {
        // Create an SMT-LIB input string with linear real arithmetic assertions
        //
        // This example is SAT:
        //
        //   x0 + x1      <= 5
        // 2 x0      + x2 >= 2
        //      - x1 + x2 <= 3
        //
        // --> x0 = 1, x1 = 0, x2 = 0
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(declare-fun x1 () Real)
(declare-fun x2 () Real)
(assert (<= (+ x0 x1) 5))
(assert (>= (+ (* 2 x0) x2) 2))
(assert (<= (+ (* (- 1) x1) x2) 3))
(assert (>= x0 0))
(assert (>= x1 0))
(assert (>= x2 0))
(check-sat)
    "#;

        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        assert!(matches!(result, SolverDecision::FEASIBLE(_)));
    }

    #[test]
    fn test_smt_to_lra_solver_infeasible() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(declare-fun x1 () Real)
(assert (<= x0 0))
(assert (<= x1 0))
(assert (>= (+ x0 x1) 1))
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        assert!(matches!(result, SolverDecision::INFEASIBLE(_)));
    }

    #[test]
    fn test_frontend_boolean_literals() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-const a Bool)
(declare-const b Bool)
(declare-fun x0 () Real)
(assert (<= x0 0))
(assert (! a :named a-bool-lit))
(assert (not b))
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        assert!(matches!(result, SolverDecision::FEASIBLE(_)));
    }

    #[test]
    fn test_smt_to_lra_solver_with_div() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x0 () Real)
(assert (<= (/ x0 2) 0))
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        assert!(matches!(result, SolverDecision::FEASIBLE(_)));
    }

    #[test]
    fn test_left_assoc_minus() {
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x () Real)
(assert (= x (- 1 2 3)))  ; x = (1 - 2) - 3 = -4
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        match result {
            SolverDecision::FEASIBLE(model) => {
                let x_var = solver.get_var("x").unwrap();
                assert_eq!(model.get(&x_var), Some(&rbig!(-4)));
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_uninterpreted_fun() {
        let smt_input = r#"
(declare-fun f (Int) Int)
(declare-fun x () Int)
(assert (= (f x) (+ 1 2)))  ; (f x) = 1 + 2 = 3
(assert (= x (f x)))
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        match result {
            SolverDecision::FEASIBLE(model) => {
                let x_var = solver.get_var("x").unwrap();
                assert_eq!(model.get(&x_var), Some(&rbig!(3)));
            }
            _ => unreachable!(),
        }
    }

    #[test]
    fn test_d0_div_by_zero_bug() {
        let smt_input = r#"
(declare-const i Int)
(declare-const j Int)
; j = 1, i < 0, i < j ==> satisfiable by any i < 0 and j = 1
(assert (= 1 j))
(assert (> 0 i))
(assert (< i j))
(check-sat)
    "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let result = solver
            .solve()
            .expect("Failed to run simplex algorithm")
            .decision;
        assert!(matches!(result, SolverDecision::FEASIBLE(_)));
    }

    #[test]
    fn test_div_zero_by_c() {
        let smt_input = r#"
(declare-fun C () Int)
(assert (= C 1))
(assert (= 1 (div 0 C)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default());
        assert!(result.is_err_and(
            |e| e == FrontendError("non-linear integer division is not supported".to_string())
        ));
    }

    /// Regression test for the integer-division bug fix.
    ///
    /// Before the fix, `(div x 2)` was treated as *real* division `x * (1/2)`,
    /// so `(= (div x 2) 1)` forced `x = 2` exactly. Under correct SMT-LIB
    /// Euclidean semantics, `(div x 2) = 1` means `2 <= x <= 3`, so `x = 3`
    /// is feasible (`floor(3/2) = 1`).
    ///
    /// Pre-fix: INFEASIBLE (x = 3 contradicts x = 2). Post-fix: FEASIBLE.
    #[test]
    fn test_int_div_floor_semantics_sat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const x Int)
(assert (= x 3))
(assert (= (div x 2) 1))  ; floor(3/2) = 1, holds under Euclidean div only
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::FEASIBLE(_)),
            "x = 3 satisfies floor(x/2) = 1; pre-fix real division would reject it"
        );
    }

    /// Regression test: dividing a constant odd numerator must floor.
    ///
    /// Before the fix, `(div 7 2)` evaluated to the exact rational `7/2`, so
    /// `(= r (div 7 2))` with `(= r 3)` was INFEASIBLE (3 != 3.5). Under
    /// Euclidean semantics `(div 7 2) = 3`, so the system is FEASIBLE.
    #[test]
    fn test_int_div_constant_floor_sat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (div 7 2)))  ; Euclidean: 7 = 2*3 + 1, so r = 3
(assert (= r 3))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::FEASIBLE(_)),
            "div 7 2 = 3 under Euclidean semantics; pre-fix it was the rational 3.5"
        );
    }

    /// Regression test: the result of `(div x 2)` must be `(= r 3.5)`-free,
    /// i.e. the exact-division witness must be rejected.
    ///
    /// Before the fix, `(= r (div 7 2))` with `(= r (/ 7 2))`-style reasoning
    /// allowed `r = 7/2`. Here we assert `r = 4`, which is consistent with
    /// neither semantics, but the *contrast* case `r = 3` (above) only passes
    /// post-fix. This case stays INFEASIBLE under both, guarding the upper
    /// bound of the Euclidean remainder constraint (7 - 2*4 = -1 < 0).
    #[test]
    fn test_int_div_constant_floor_unsat_wrong_quotient() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (div 7 2)))
(assert (= r 4))  ; 2*4 = 8 > 7, violates remainder bound 0 <= 7 - 2q
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::INFEASIBLE(_)),
            "q = 4 violates 0 <= 7 - 2q; div 7 2 must equal 3"
        );
    }

    /// Regression test: Euclidean division of a negative numerator floors
    /// toward negative infinity (remainder is non-negative).
    ///
    /// `(div (- 1) 2)`: -1 = 2*(-1) + 1 with 0 <= 1 < 2, so the quotient is -1
    /// (not 0, which exact division toward zero would give, and not -0.5 which
    /// the pre-fix real-division handling produced).
    #[test]
    fn test_int_div_negative_numerator_floors() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (div (- 1) 2)))  ; Euclidean: -1 = 2*(-1) + 1, so r = -1
(assert (= r (- 1)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::FEASIBLE(_)),
            "div (-1) 2 = -1 under Euclidean semantics; pre-fix it was -0.5"
        );
    }

    /// Regression test: Euclidean division by a negative denominator floors
    /// toward zero (remainder is non-negative).
    ///
    /// `(div 9 (- 2))`: 9 = (-2)*(-4) + 1 with 0 <= 1 < |-2|, so the quotient is -4
    #[test]
    fn test_int_div_negative_denominator_floors() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const r Int)
(assert (= r (div 9 (- 2))))  ; Euclidean: 9 = (-2)*(-4) + 1, so r = -4
(assert (= r (- 4)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::FEASIBLE(_)),
            "div (-1) 2 = -1 under Euclidean semantics; pre-fix it was -0.5"
        );
    }

    /// Regression test: equality elimination conflict provenance must propagate
    /// through the solver when elimination doesn't produce trivial-unsat but the
    /// remaining system is infeasible.
    ///
    /// System: x = 5, x <= 3, y >= 10
    /// After elimination: 0 <= -2 (trivially unsat from x <= 3 with x=5)
    /// But if the trivial detection doesn't catch it (e.g., with more complex systems),
    /// the solver conflict must still include the equality.
    ///
    /// Here we use a system where elimination removes the equality but the
    /// remaining system is still infeasible, discovered by the solver.
    #[test]
    fn test_equality_elim_conflict_provenance_through_solver() {
        // x = y + 1, y >= 3, x <= 2
        // After eliminating x = y + 1: y + 1 <= 2 (i.e., y <= 1) and y >= 3
        // The solver detects infeasibility from y <= 1 and y >= 3
        // The conflict must include the equality x = y + 1 in addition to
        // the two inequalities.
        let smt_input = r#"
(set-logic QF_LRA)
(declare-fun x () Real)
(declare-fun y () Real)
(assert (= x (+ y 1)))
(assert (>= y 3))
(assert (<= x 2))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).unwrap();
        match result {
            SolverDecisionApi::INFEASIBLE(conflict) => {
                // The conflict should have at least 2 relations (the two inequalities)
                // and ideally 3 (including the equality)
                assert!(
                    conflict.len() >= 2,
                    "conflict must include at least the inequalities, got {}",
                    conflict.len()
                );
            }
            _ => panic!("expected INFEASIBLE"),
        }
    }

    /// `−1 < x − y < 0` has no integer solution but is feasible over the rationals, and
    /// nothing bounds `x` or `y`. Without integer tightening, branch-and-bound on `x`/`y` never
    /// terminates (the relaxation slides off to infinity); tightened to `x − y ≤ −1 ∧ x − y ≥ 0`
    /// the relaxation is infeasible outright.
    #[test]
    fn test_unbounded_integer_strip_unsat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const x Int)
(declare-const y Int)
(assert (< (- x y) 0))
(assert (> (- x y) (- 1)))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)));
    }

    /// Same strip, but only visible after equality elimination substitutes `a = y + 1`:
    /// `0 <= 2x − a − y <= 0` is tight as written, but becomes `1 <= 2(x − y) <= 1`, i.e.
    /// `x − y = 1/2`. The post-elimination tightening reduces it to `x − y >= 1 ∧ x − y <= 0`.
    #[test]
    fn test_unbounded_integer_strip_after_elimination_unsat() {
        let smt_input = r#"
(set-logic QF_LIA)
(declare-const x Int)
(declare-const y Int)
(declare-const a Int)
(assert (= a (+ y 1)))
(assert (<= (- (* 2 x) a y) 0))
(assert (>= (- (* 2 x) a y) 0))
(check-sat)
    "#;
        let result = solve_smtlib(smt_input, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)));
    }
}
