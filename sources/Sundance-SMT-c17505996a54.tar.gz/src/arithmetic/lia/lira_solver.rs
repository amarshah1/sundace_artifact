// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

//! Linear integer and real arithmetic solver
//!
//! The [LIRASolver] is a wrapper around [LRASolver] which manages solver state for mixed
//! integer and real arithmetic problems.

use dashu::{Integer, Rational};

use crate::arithmetic::lia::config::SolverConfig;
use crate::arithmetic::lia::lra_solver::LRASolver;
use crate::arithmetic::lia::qdelta::QDelta;
use crate::arithmetic::lia::solver_result::{
    Assignment, BoundRef, Conflict, SolverDecision, SolverResult, SolverReturn,
};
use crate::arithmetic::lia::stats::Stats;
use crate::arithmetic::lia::variables::{Var, VarType};
use crate::debug_println;
use std::time::Instant;

/// Outcome of exploring one node of the branch-and-bound tree.
///
/// Branch-and-bound is a depth-first search over the tree of integer bound refinements. Each node
/// solves the rational relaxation under the bounds asserted along the path from the root; one of
/// these is returned for every node, and a parent combines its two children's outcomes into its
/// own. See [`LIRASolver::branch_iterative`].
enum NodeOutcome {
    /// A rational assignment satisfying every integrality constraint in scope. The search
    /// short-circuits on the first one found.
    Feasible(Assignment<Var>),
    /// The subtree rooted at this node is infeasible; the [`Conflict`] is a subset of the
    /// asserted bounds that explains why.
    ///
    /// Each [`BoundRef`] refers to the bound on that side of the variable asserted closest to
    /// this node: on the path from the root, every branch bound on `x` is strictly tighter than
    /// the earlier bounds on the same side, so it is the one the LRA solver used. A node therefore
    /// owns exactly the bound it asserts, and once it is done with its children, the bounds left
    /// in their conflicts that name the same variable refer to bounds asserted further up.
    Pruned(Conflict<BoundRef>),
    /// The search hit a resource limit (LRA-solve budget or maximum depth) before proving
    /// feasibility or infeasibility.
    Unknown,
}

/// Which side of a branch to assert for an integer variable `x` currently sitting at a
/// fractional value `v`. The two sides partition the integers: `x <= floor(v)` or
/// `x >= ceil(v)`, so together they lose no integer solutions.
#[derive(Clone, Copy)]
enum BranchSide {
    /// Assert `x <= floor(v)` as an upper bound.
    Floor,
    /// Assert `x >= ceil(v)` as a lower bound.
    Ceil,
}

impl BranchSide {
    /// The bound on `x` asserted by this side of the branch.
    fn bound_ref(self, x: Var) -> BoundRef {
        match self {
            BranchSide::Floor => BoundRef::upper(x),
            BranchSide::Ceil => BoundRef::lower(x),
        }
    }
}

/// One node of the branch-and-bound search, held on an explicit heap stack rather than the
/// call stack (see [`LIRASolver::branch_iterative`]). Each frame records where it is in
/// exploring its two children so the search can be suspended and resumed as the stack grows
/// and shrinks.
struct BranchFrame {
    /// The fractional integer variable this node branches on.
    x: Var,
    /// Upper bound for the floor branch (`x <= floor_bound`).
    floor_bound: Integer,
    /// Lower bound for the ceil branch (`x >= ceil_bound`).
    ceil_bound: Integer,
    /// Distance from the root; drives the depth guard in [`LIRASolver::over_budget`].
    depth: usize,
    /// Which child this frame is about to explore or is currently waiting on.
    stage: Stage,
    /// The floor branch's conflict, kept while the ceil branch runs so the two can be
    /// resolved on `x`'s branch bounds once both branches are pruned.
    floor_conflict: Option<Conflict<BoundRef>>,
    /// LRA backtrack level to restore once the currently-awaited child completes. `None`
    /// when no bound is outstanding (the child finished without recursing, or none started).
    pending_level: Option<usize>,
}

/// Where a [`BranchFrame`] is in exploring its two children.
#[derive(Clone, Copy)]
enum Stage {
    /// Yet to explore the floor branch.
    ExploreFloor,
    /// Floor branch is running; its outcome is pending.
    AwaitFloor,
    /// Floor branch was pruned by a conflict on its bound `U(x)`; yet to explore the ceil
    /// branch.
    ExploreCeil,
    /// Ceil branch is running; its outcome is pending.
    AwaitCeil,
}

/// Result of entering a branch node: either it was solved immediately (the relaxation is
/// already integral) or it needs a [`BranchFrame`] pushed to explore its children.
enum Descent {
    Solved(NodeOutcome),
    Branch(BranchFrame),
}

/// Result of asserting one branch bound and solving the relaxation under it.
enum ExploreStep {
    /// Exploration finished without recursing; the LRA solver has already been backtracked
    /// to its pre-assertion state.
    Done(NodeOutcome),
    /// The relaxation is feasible but not yet integral, so a child branch should run at
    /// `depth + 1`. The asserted bound is still live; `level` must be backtracked once the
    /// child subtree completes.
    Recurse { level: usize },
}

/// Linear integer and real arithmetic solver.
///
/// Wraps an [`LRASolver`] and adds integrality reasoning via branch-and-bound. The LRA
/// solver is used incrementally: the search asserts a bound, recurses, then backtracks to
/// the saved level, so a single [`LRASolver`] instance serves the whole tree.
#[derive(Debug)]
pub struct LIRASolver {
    /// The underlying LRA solver, driven incrementally across the whole search.
    lra_solver: LRASolver,
    /// Solver configuration.
    config: SolverConfig,
    /// Runtime statistics for the current [`Self::solve`] call. Reset at the start of every
    /// `solve` and accumulated across the LRA solves that call performs, so a reused
    /// `LIRASolver` never carries stats — or the [`SolverConfig::max_lra_solve_calls`] budget
    /// derived from them — over from an earlier `solve`.
    stats: Stats,
}

impl LIRASolver {
    /// Create a new LIRASolver wrapping the given LRASolver.
    pub fn new(lra_solver: LRASolver, config: SolverConfig) -> Self {
        Self {
            lra_solver,
            config,
            stats: Stats::new(),
        }
    }

    /// Solve a mixed integer/real system.
    ///
    /// First tries cheap heuristics (unit cube test, rounding) against the rational
    /// relaxation, then falls back to branch-and-bound. Returns `FEASIBLE` with a model,
    /// `INFEASIBLE` with a conflict core, or `UNKNOWN` if a resource limit was hit.
    ///
    /// A `LIRASolver` is safe to reuse across `solve` calls: each call resets its own per-call
    /// state up front, so the caller need not track anything between calls. Both the returned
    /// [`SolverReturn`] and the [`SolverConfig::max_lra_solve_calls`] budget describe this one
    /// call.
    pub fn solve(&mut self) -> SolverResult<SolverReturn> {
        debug_println!(21, 0, "lia::lira_solver: starting LIRASolver");

        // Clear any terminal `Unsat` state left by a previous `solve` (or by branch-and-bound
        // within one). While the underlying solver is `Unsat`, `set_backtrack` is a no-op and so is
        // its matching `backtrack`. Clearing it here makes reuse transparent to the caller.
        self.lra_solver.clear_unsat_state();

        // Stats are per-call: they are reset here so the returned [`SolverReturn`] describes
        // *this* solve, and so the [`SolverConfig::max_lra_solve_calls`] budget checked by
        // [`Self::over_budget`] is a per-solve budget.
        self.stats = Stats::new();

        // The unit cube test can find an integer point with a single LRA solve, so try it
        // before further testing the relaxation and integer bounded branches.
        debug_println!(21, 0, "lia::lira_solver::solve: trying the unit cube test");
        if let Some(cube_assg) = self.lra_solver.try_unit_cube_test()? {
            debug_println!(21, 0, "lia::lira_solver::solve: unit cube test succeeded");
            return Ok(self.finish(SolverDecision::FEASIBLE(cube_assg)));
        }

        // Solve the rational relaxation once up front. If it is infeasible or already
        // integral we are done; otherwise try the rounding heuristic before branching.
        debug_println!(21, 0, "lia::lira_solver::solve: solving the relaxation");
        let ret = self.lra_solver.solve()?;
        self.stats.combine(&ret.stats);

        match ret.decision {
            SolverDecision::INFEASIBLE(cs) => Ok(self.finish(SolverDecision::INFEASIBLE(cs))),
            SolverDecision::UNKNOWN => Ok(self.finish(SolverDecision::UNKNOWN)),
            SolverDecision::FEASIBLE(assg) => {
                debug_println!(
                    21,
                    0,
                    "lia::lira_solver::solve: relaxation feasible:\n{assg}"
                );

                // The relaxation already satisfies every integrality constraint.
                if self.find_fractional_int_var().is_none() {
                    return Ok(self.finish(SolverDecision::FEASIBLE(assg)));
                }

                debug_println!(21, 0, "lia::lira_solver::solve: trying rounding heuristic");
                if let Some(rounded) = self.lra_solver.try_rounding_heuristic() {
                    debug_println!(21, 0, "lia::lira_solver::solve: rounding succeeded");
                    return Ok(self.finish(SolverDecision::FEASIBLE(rounded)));
                }

                // Fall back to branch-and-bound. The relaxation is already solved and its
                // state is live in the LRA solver, so start exploring from the root at
                // depth 0 rather than re-solving.
                debug_println!(21, 0, "lia::lira_solver: starting branch-and-bound");
                let outcome = self.branch_iterative(0)?;
                Ok(self.finish(match outcome {
                    NodeOutcome::Feasible(assg) => SolverDecision::FEASIBLE(assg),
                    NodeOutcome::Pruned(conflict) => SolverDecision::INFEASIBLE(conflict.vars()),
                    NodeOutcome::Unknown => SolverDecision::UNKNOWN,
                }))
            }
        }
    }

    /// Branch-and-bound driven by an explicit heap stack instead of the call stack.
    ///
    /// This is a direct iterative rendering of the recursive descent: each `BranchFrame` on
    /// `stack` is one node whose relaxation was feasible-but-fractional, and `stage` records
    /// which child it is exploring. Because depth is now bounded by heap memory rather than
    /// the OS thread stack, [`SolverConfig::max_branch_depth`] can be set far higher than a
    /// recursive version could safely tolerate.
    ///
    /// The per-node combine rules are unchanged from the recursive form:
    /// - either child feasible -> propagate it up (the search is done),
    /// - either child pruned by a conflict not mentioning the bound it asserted on `x`
    ///   (`U(x)` for floor, `L(x)` for ceil) -> that conflict alone proves this node
    ///   infeasible, so the other branch is irrelevant and skipped,
    /// - both children pruned -> resolve the two conflicts on the branch bounds (drop `U(x)`
    ///   from the floor conflict and `L(x)` from the ceil conflict, union the rest), yielding
    ///   this node's conflict.
    ///
    /// Conflicts are kept as sets of [`BoundRef`]s rather than variables because `x` may be
    /// branched on again further down the same path. A conflict found below can then depend on
    /// a bound on `x` asserted by a node above this one, which must survive the resolution here.
    ///
    /// The LRA solver is still driven incrementally with the same
    /// set_backtrack/assert/solve/backtrack discipline the recursion used: every bound
    /// asserted on the way down is undone on the way back up, in strict LIFO order.
    fn branch_iterative(&mut self, root_depth: usize) -> SolverResult<NodeOutcome> {
        let mut stack: Vec<BranchFrame> = Vec::new();
        match self.descend(root_depth)? {
            // The root relaxation is already integral (or otherwise decided) — no branching.
            Descent::Solved(outcome) => Ok(outcome),
            Descent::Branch(frame) => {
                stack.push(frame);
                self.run(&mut stack)
            }
        }
    }

    /// Drive the explicit stack to completion, returning the root node's outcome.
    ///
    /// `stack` must contain exactly the root frame on entry. On return the stack is empty and
    /// the LRA solver has been backtracked to its state before branching began.
    ///
    /// `child` carries the outcome bubbling up from the most-recently-finished node to the
    /// frame that explored it; it is consumed by the `Await*` stages and, once the stack is
    /// empty, holds the root's outcome.
    fn run(&mut self, stack: &mut Vec<BranchFrame>) -> SolverResult<NodeOutcome> {
        let mut child: Option<NodeOutcome> = None;

        while let Some(top) = stack.len().checked_sub(1) {
            // Once a node is Feasible or Unknown, every frame above it only passes that outcome
            // up. Undo all their branch bounds with one backtrack to the outermost pending level
            // instead of one assignment restore per frame: after a deadline, a deep stack would
            // otherwise take long to unwind.
            if matches!(
                child,
                Some(NodeOutcome::Feasible(_)) | Some(NodeOutcome::Unknown)
            ) {
                if let Some(level) = stack.iter().filter_map(|f| f.pending_level).min() {
                    self.lra_solver.backtrack(level);
                }
                stack.clear();
                break;
            }
            match stack[top].stage {
                // Explore the floor branch: x <= floor(val).
                Stage::ExploreFloor => {
                    let (x, bound, depth) = (
                        stack[top].x,
                        stack[top].floor_bound.clone(),
                        stack[top].depth,
                    );
                    match self.step(x, BranchSide::Floor, bound, depth)? {
                        // Floor branch finished without recursing. Combine at this node.
                        ExploreStep::Done(outcome) => {
                            Self::combine_floor(stack, &mut child, outcome)
                        }
                        // Floor branch is feasible-but-fractional; descend into its child.
                        ExploreStep::Recurse { level } => {
                            stack[top].stage = Stage::AwaitFloor;
                            stack[top].pending_level = Some(level);
                            self.push_child(stack, depth + 1, &mut child)?;
                        }
                    }
                }

                // The floor child we descended into has returned in `child`.
                Stage::AwaitFloor => {
                    let outcome = child.take().expect("await floor without child outcome");
                    let level = stack[top]
                        .pending_level
                        .take()
                        .expect("await floor without level");
                    self.lra_solver.backtrack(level);
                    Self::combine_floor(stack, &mut child, outcome);
                }

                // Explore the ceil branch: x >= ceil(val).
                Stage::ExploreCeil => {
                    let (x, bound, depth) = (
                        stack[top].x,
                        stack[top].ceil_bound.clone(),
                        stack[top].depth,
                    );
                    match self.step(x, BranchSide::Ceil, bound, depth)? {
                        ExploreStep::Done(outcome) => {
                            Self::combine_ceil(stack, &mut child, outcome)
                        }
                        ExploreStep::Recurse { level } => {
                            stack[top].stage = Stage::AwaitCeil;
                            stack[top].pending_level = Some(level);
                            self.push_child(stack, depth + 1, &mut child)?;
                        }
                    }
                }

                // The ceil child we descended into has returned in `child`.
                Stage::AwaitCeil => {
                    let outcome = child.take().expect("await ceil without child outcome");
                    let level = stack[top]
                        .pending_level
                        .take()
                        .expect("await ceil without level");
                    self.lra_solver.backtrack(level);
                    Self::combine_ceil(stack, &mut child, outcome);
                }
            }
        }

        Ok(child.expect("stack drained without producing a root outcome"))
    }

    /// Fold the floor branch's `outcome` into the top frame: pop-and-propagate if the node is
    /// decided, or advance it to the ceil branch otherwise.
    fn combine_floor(
        stack: &mut Vec<BranchFrame>,
        child: &mut Option<NodeOutcome>,
        outcome: NodeOutcome,
    ) {
        let top = stack.len() - 1;
        let x = stack[top].x;
        match outcome {
            NodeOutcome::Feasible(assg) => {
                Self::finish_frame(stack, child, NodeOutcome::Feasible(assg))
            }
            NodeOutcome::Unknown => Self::finish_frame(stack, child, NodeOutcome::Unknown),
            NodeOutcome::Pruned(floor_conflict) => {
                // Optimization: a floor conflict independent of the floor bound proves this node
                // infeasible on its own; the ceil branch cannot change that, so skip it.
                let floor_bound = BranchSide::Floor.bound_ref(x);
                if !floor_conflict.contains(&floor_bound) {
                    debug_println!(
                        15,
                        0,
                        "lia::lira_solver: floor conflict independent of {floor_bound}"
                    );
                    Self::finish_frame(stack, child, NodeOutcome::Pruned(floor_conflict));
                } else {
                    // Keep the floor conflict and explore the ceil branch next.
                    stack[top].floor_conflict = Some(floor_conflict);
                    stack[top].stage = Stage::ExploreCeil;
                }
            }
        }
    }

    /// Fold the ceil branch's `outcome` into the top frame, then pop-and-propagate the node's
    /// final outcome.
    fn combine_ceil(
        stack: &mut Vec<BranchFrame>,
        child: &mut Option<NodeOutcome>,
        outcome: NodeOutcome,
    ) {
        let top = stack.len() - 1;
        let x = stack[top].x;
        let final_outcome = match outcome {
            NodeOutcome::Feasible(assg) => NodeOutcome::Feasible(assg),
            NodeOutcome::Unknown => NodeOutcome::Unknown,
            NodeOutcome::Pruned(mut ceil_conflict) => {
                let ceil_bound = BranchSide::Ceil.bound_ref(x);
                if !ceil_conflict.contains(&ceil_bound) {
                    debug_println!(
                        15,
                        0,
                        "lia::lira_solver: ceil conflict independent of {ceil_bound}"
                    );
                    NodeOutcome::Pruned(ceil_conflict)
                } else {
                    // Both branches are infeasible and both depend on their branch bound. Resolve
                    // on the branch bounds to obtain a conflict that no longer mentions them,
                    // proving this node infeasible. Any other bound on `x` in either conflict was
                    // asserted above this node and stays.
                    let mut floor_conflict = stack[top]
                        .floor_conflict
                        .take()
                        .expect("ceil branch completed without a saved floor conflict");
                    floor_conflict.remove(&BranchSide::Floor.bound_ref(x));
                    ceil_conflict.remove(&ceil_bound);
                    let resolved = floor_conflict.union(&ceil_conflict);
                    // An empty resolved would surface as `Infeasible({})`, which the propagator
                    // reads as an empty learned clause and hence unconditional (global) UNSAT.
                    // That is only ever the case if each branch was infeasible on its branch
                    // bound *alone*. A single bound is always satisfiable on its own, and at a
                    // fractional node `L(x) <= floor(v) < v < ceil(v) <= U(x)`, so neither branch
                    // can be trivially infeasible either: a real relaxation conflict always drags
                    // in the other bounds that constrained `x`. The `resolved` is therefore never
                    // empty.
                    assert!(
                        !resolved.is_empty(),
                        "branch-and-bound resolved an empty conflict on {x:?}; \
                         an empty theory core would force spurious global UNSAT"
                    );
                    NodeOutcome::Pruned(resolved)
                }
            }
        };
        Self::finish_frame(stack, child, final_outcome);
    }

    /// Pop the top frame and hand its `outcome` to whatever explored it (its parent frame, or
    /// the caller if it was the root) by stashing it in `child`.
    fn finish_frame(
        stack: &mut Vec<BranchFrame>,
        child: &mut Option<NodeOutcome>,
        outcome: NodeOutcome,
    ) {
        stack.pop();
        *child = Some(outcome);
    }

    /// Enter a branch node given the LRA solver already holds a feasible rational model.
    ///
    /// Returns [`Descent::Solved`] when the model is already integral (a real solution), and
    /// [`Descent::Branch`] with a fresh [`BranchFrame`] otherwise. `depth` is the node's
    /// distance from the root.
    fn descend(&mut self, depth: usize) -> SolverResult<Descent> {
        let (x, val) = match self.find_fractional_int_var() {
            // Every integer variable is integral: this rational model is a real solution.
            None => {
                let model = self
                    .lra_solver
                    .get_rational_model()
                    .expect("feasible node must have a rational model");
                return Ok(Descent::Solved(NodeOutcome::Feasible(Assignment::new(
                    model,
                ))));
            }
            Some(pair) => pair,
        };
        debug_println!(15, 0, "lia::lira_solver: branching on {x} = {val}");
        Ok(Descent::Branch(BranchFrame {
            x,
            floor_bound: val.floor(),
            ceil_bound: val.ceil(),
            depth,
            stage: Stage::ExploreFloor,
            floor_conflict: None,
            pending_level: None,
        }))
    }

    /// Descend into a child node at `depth`, pushing a frame for it when it needs further
    /// branching or writing its immediate outcome to `child` when it is solved outright.
    fn push_child(
        &mut self,
        stack: &mut Vec<BranchFrame>,
        depth: usize,
        child: &mut Option<NodeOutcome>,
    ) -> SolverResult<()> {
        match self.descend(depth)? {
            Descent::Solved(outcome) => *child = Some(outcome),
            Descent::Branch(frame) => stack.push(frame),
        }
        Ok(())
    }

    /// Assert one side of a branch on `x` and solve the relaxation under it.
    ///
    /// `bound` is `floor(val)` (asserted as an upper bound) or `ceil(val)` (asserted as a
    /// lower bound) depending on `side`.
    ///
    /// Returns [`ExploreStep::Done`] — with the LRA solver already backtracked — when the
    /// branch resolves without needing a child (budget hit, trivial contradiction, or an
    /// infeasible relaxation). Returns [`ExploreStep::Recurse`] with the outstanding
    /// backtrack `level` when the relaxation is feasible-but-fractional and a child should be
    /// explored; the caller must `backtrack(level)` once that child completes.
    fn step(
        &mut self,
        x: Var,
        side: BranchSide,
        bound: Integer,
        depth: usize,
    ) -> SolverResult<ExploreStep> {
        // Guard the LRA-solve budget and the (now heap-bounded) branch depth.
        if self.over_budget(depth) {
            return Ok(ExploreStep::Done(NodeOutcome::Unknown));
        }

        // A previously-pruned sibling branch leaves the LRA solver `Unsat`, and `set_backtrack` is
        // a no-op in that state. Clear it first so the assert/solve/backtrack triple around this
        // branch is properly scoped.
        self.lra_solver.clear_unsat_state();
        let level = self.lra_solver.set_backtrack();
        let qbound = QDelta::from(Rational::from(bound));
        let assert_res = match side {
            BranchSide::Floor => self.lra_solver.assert_upper(&x, &qbound)?,
            BranchSide::Ceil => self.lra_solver.assert_lower(&x, &qbound)?,
        };

        if let Some(false) = assert_res {
            // The bound directly contradicts an existing one on `x`, so the branch is
            // infeasible without any solving. The conflict is `x`'s two bounds alone.
            debug_println!(
                15,
                0,
                "lia::lira_solver: branch on {x} trivially infeasible"
            );
            self.lra_solver.backtrack(level);
            return Ok(ExploreStep::Done(NodeOutcome::Pruned(
                [BoundRef::lower(x), BoundRef::upper(x)]
                    .into_iter()
                    .collect(),
            )));
        }

        // Solve the relaxation under the new bound.
        let (ret, bound_conflict) = self.lra_solver.solve_with_bound_conflict()?;
        self.stats.combine(&ret.stats);
        match ret.decision {
            SolverDecision::INFEASIBLE(_) => {
                self.lra_solver.backtrack(level);
                let conflict = bound_conflict.expect("infeasible solve without a bound conflict");
                Ok(ExploreStep::Done(NodeOutcome::Pruned(conflict)))
            }
            // Feasible but not necessarily integral: keep the bound live and branch deeper.
            // The caller backtracks `level` once the child subtree completes.
            SolverDecision::FEASIBLE(_) => Ok(ExploreStep::Recurse { level }),
            SolverDecision::UNKNOWN => {
                unreachable!("lra_solver decision cannot be UNKNOWN after solve")
            }
        }
    }

    /// Whether the search should stop and report `UNKNOWN`, because either the configured
    /// LRA-solve budget or the maximum branch depth (also the recursion-depth guard) has
    /// been reached.
    fn over_budget(&self, depth: usize) -> bool {
        if let Some(deadline) = self.config.deadline
            && Instant::now() >= deadline
        {
            debug_println!(21, 0, "lia::lira_solver: deadline reached");
            return true;
        }
        if let Some(max) = self.config.max_lra_solve_calls
            && self.stats.num_lra_solve > max
        {
            debug_println!(21, 0, "lia::lira_solver: max LRA-solve calls reached");
            return true;
        }
        if let Some(max) = self.config.max_branch_depth
            && depth >= max
        {
            debug_println!(21, 0, "lia::lira_solver: max branch depth reached");
            return true;
        }
        false
    }

    /// Wrap a decision together with the accumulated stats into a [`SolverReturn`].
    fn finish(&self, decision: SolverDecision) -> SolverReturn {
        SolverReturn::new(decision, self.stats.clone())
    }

    /// Get a reference to the underlying LRASolver.
    pub fn lra_solver(&self) -> &LRASolver {
        &self.lra_solver
    }

    /// Get a mutable reference to the underlying LRASolver.
    pub fn lra_solver_mut(&mut self) -> &mut LRASolver {
        &mut self.lra_solver
    }

    /// Find the first integer-typed variable whose current rational assignment is not
    /// integral, returning it with that value. `None` means the model is fully integral.
    ///
    /// TODO: track integer variables separately to avoid scanning the whole model.
    fn find_fractional_int_var(&self) -> Option<(Var, Rational)> {
        let model = self.lra_solver.get_rational_model()?;
        model
            .iter()
            .find(|(var, val)| var.typ == VarType::Int && !val.is_int())
            .map(|(var, val)| (*var, val.clone()))
    }
}

/// The tests in this module were ported from integration tests. As such, they use the frontend
/// `solve_smtlib` and solver construction methods rather than the LIRASolver methods
/// directly.
#[cfg(test)]
mod tests {
    use dashu::{Rational, rbig};

    use crate::arithmetic::lia::config::SolverConfig;
    use crate::arithmetic::lia::frontend::{smt_to_lra_solver, solve_smtlib};
    use crate::arithmetic::lia::lira_solver::LIRASolver;
    use crate::arithmetic::lia::solver_result::SolverDecision;
    use crate::arithmetic::lia::solver_result_api::SolverDecisionApi;

    /// Execute branch and bound manually on an UNSAT QF_LIA problem
    #[test]
    fn manual_branch_and_bound_triangle() {
        // If x, y are Real this problem is FEASBILE, ex. model {x := 1/3, y := 1/3}
        let smt_input = r#"
        (set-logic QF_LIRA)
        (declare-fun x () Real)
        (declare-fun y () Int)
        (assert (>= (to_real y) x))                  ; y >= x
        (assert (>= x (/ (to_real 1) (to_real 3))))  ; x >= 1/3
        (assert (<= (to_real y) (/ (to_real 2) (to_real 3))))  ; y <= 2/3
            "#;
        let mut solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let ass = match solver.solve().unwrap().decision {
            SolverDecision::FEASIBLE(ass) => ass,
            _ => unreachable!(),
        };

        // select an integer variable whose assignment is not an integer
        let y_var = solver.get_var("y").unwrap();
        let y_val = ass.get(&y_var).unwrap();
        assert!(y_val >= &rbig!(1 / 3) && y_val <= &rbig!(2 / 3));
        let y0 = y_val;

        // for y to be integral it must either be below this value
        let lower_branch_0 = Rational::from(y0.floor());
        // or above this value
        let upper_branch_0 = Rational::from(y0.ceil());

        // consider original problem S_0 branched and new problems
        // {S_0, y <= lower_branch_0}, {S_0, y >= upper_branch_0} active

        let level_0 = solver.set_backtrack();

        assert_eq!(
            solver
                // the new lower branch corresponds to a tighter upper bound
                .assert_upper(&y_var, &lower_branch_0.into())
                .expect("assert_upper failed"),
            None // satisfiability unknown
        );
        // lower branch is infeasible
        assert!(matches!(
            solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));

        solver.backtrack(level_0);

        assert_eq!(
            solver
                // the new lower branch corresponds to a tighter upper bound
                .assert_lower(&y_var, &upper_branch_0.into())
                .expect("assert_lower failed"),
            None // satisfiability unknown
        );
        // upper branch is infeasible
        assert!(matches!(
            solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));

        // all branches are pruned, therefor the problem is mixed integer infeasible
        // -> in the LIRA solver we would now backtrack to `level_0` and set solver state
        //    to UNSAT
    }

    // Repeat the manual test above but using the actual LIRA solver branch-and-bound implementation
    #[test]
    fn branch_and_bound_triangle() {
        // If x, y are Real this problem is FEASBILE, ex. model {x := 1/3, y := 1/3}
        let smt_input = r#"
        (set-logic QF_LIRA)
        (declare-fun x () Real)
        (declare-fun y () Int)
        (assert (>= (to_real y) x))                  ; y >= x
        (assert (>= x (/ (to_real 1) (to_real 3))))  ; x >= 1/3
        (assert (<= (to_real y) (/ (to_real 2) (to_real 3))))  ; y <= 2/3
            "#;
        let lra_solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());
        assert!(matches!(
            lira_solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));
    }

    /// Stats and hence the `max_lra_solve_calls` budget derived from them are per-call.
    ///
    /// A `LIRASolver` kept alive across several `solve` calls (as an incremental frontend does)
    /// must not accumulate `num_lra_solve`, or it would eventually exceed any finite budget and
    /// report `UNKNOWN` on every subsequent call regardless of the problem's difficulty.
    #[test]
    fn stats_are_reset_per_solve() {
        let smt_input = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (declare-fun y () Int)
        (assert (>= y x))
        (assert (>= (* 3 x) 1))
        (assert (<= (* 3 y) 2))
            "#;
        // A budget just large enough for one solve, but which repeated solves would exhaust if
        // stats accumulated across calls.
        let config = SolverConfig {
            max_lra_solve_calls: Some(8),
            ..SolverConfig::default()
        };
        let lra_solver =
            smt_to_lra_solver(smt_input, &config).expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, config);

        let first = lira_solver.solve().unwrap();
        assert!(
            matches!(first.decision, SolverDecision::INFEASIBLE(_)),
            "expected INFEASIBLE on the first solve"
        );
        let first_solves = first.stats.num_lra_solve;
        assert!(
            first_solves > 0,
            "the solve should have run at least one LRA solve"
        );

        // Re-solving the same system must reach the same verdict with the same accounting,
        // without the caller having to reset any state between calls.
        for round in 0..3 {
            let ret = lira_solver.solve().unwrap();
            assert!(
                matches!(ret.decision, SolverDecision::INFEASIBLE(_)),
                "round {round}: expected INFEASIBLE — the per-solve budget was exhausted by \
                 stats accumulating across calls"
            );
            assert_eq!(
                ret.stats.num_lra_solve, first_solves,
                "round {round}: stats must describe this solve alone, not all solves so far"
            );
        }
    }

    /// Branch-and-bound must not leak its speculative branch bounds into the solver it was
    /// handed.
    ///
    /// Each branch is scoped by `set_backtrack` / ... / `backtrack(level)`. But
    /// `LRASolver::set_backtrack` is a no-op while the solver is `Unsat` — and pruning the floor
    /// branch leaves exactly that state — so without clearing it first the ceil branch's
    /// `set_backtrack` returns the *current* level, making the matching `backtrack` a no-op too.
    /// The ceil bound then survives `solve` and corrupts every later use of that solver.
    ///
    /// `3x >= 1 && 3x <= 2` pins `x` to `[1/3, 2/3]`: integer-infeasible, and B&B prunes the
    /// floor branch (`x <= 0`) before exploring the ceil branch (`x >= 1`). That `x >= 1` is the
    /// bound that used to leak.
    #[test]
    fn branch_and_bound_does_not_leak_branch_bounds() {
        let smt_input = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (assert (>= (* 3 x) 1))
        (assert (<= (* 3 x) 2))
            "#;
        let lra_solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());

        assert!(
            matches!(
                lira_solver.solve().unwrap().decision,
                SolverDecision::INFEASIBLE(_)
            ),
            "x must lie in [1/3, 2/3], so there is no integer solution"
        );

        // `x` itself was never directly bounded by the input (only `3x` was, via slacks), so any
        // bound left on it after the search must have come from a branch.
        let x = lira_solver.lra_solver().get_var("x").expect("x exists");
        let bounds = lira_solver
            .lra_solver()
            .get_bounds(&x)
            .expect("x has a bounds record");
        assert!(
            bounds.lower.is_none() && bounds.upper.is_none(),
            "branch-and-bound leaked a speculative bound on x: {bounds:?}"
        );
    }

    // Repeat the `branch_and_bound_triangle` test as purely LIA
    #[test]
    fn branch_and_bound_triangle_lia() {
        // If x, y are Real this problem is FEASBILE, ex. model {x := 1/3, y := 1/3}
        let smt_input = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (declare-fun y () Int)
        (assert (>= y x))        ; y >= x
        (assert (>= (* 3 x) 1))  ; 3x >= 1
        (assert (<= (* 3 y) 2))  ; 3y <= 2
            "#;
        let lra_solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());
        assert!(matches!(
            lira_solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));
    }

    /// A node where *both* branches on the same integer variable are infeasible is the only
    /// place branch-and-bound resolves two conflicts on a variable `x`. The resolvent must never be empty:
    /// an empty theory core surfaces downstream as an empty learned clause and forces spurious
    /// *global* UNSAT (see the `assert!` invariant in `combine_ceil`).
    ///
    /// Both problems below are the classic "integer trapped in a fractional interval": the real
    /// relaxation is feasible (e.g. `x = y = 1/3`) but there is no integer in `[1/3, 2/3]`, so
    /// both the floor (`y <= 0`) and ceil (`y >= 1`) branches are infeasible and get resolved.
    #[test]
    fn branch_and_bound_conflict_core_is_nonempty() {
        // LIRA form: y is Int, x is Real.
        let lira = r#"
        (set-logic QF_LIRA)
        (declare-fun x () Real)
        (declare-fun y () Int)
        (assert (>= (to_real y) x))
        (assert (>= x (/ (to_real 1) (to_real 3))))
        (assert (<= (to_real y) (/ (to_real 2) (to_real 3))))
            "#;
        // Pure-LIA form of the same trap.
        let lia = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (declare-fun y () Int)
        (assert (>= y x))
        (assert (>= (* 3 x) 1))
        (assert (<= (* 3 y) 2))
            "#;

        for smt in [lira, lia] {
            let lra_solver = smt_to_lra_solver(smt, &SolverConfig::default())
                .expect("Failed to create LRA solver");
            let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());
            match lira_solver.solve().unwrap().decision {
                SolverDecision::INFEASIBLE(conflict) => assert!(
                    !conflict.is_empty(),
                    "branch-and-bound produced an empty conflict core, which would force \
                     spurious global UNSAT downstream"
                ),
                other => panic!("expected INFEASIBLE, got {other:?}"),
            }
        }
    }

    #[test]
    fn unsat_2_sat_branch_and_bound() {
        // Encode the 2-variable 2-SAT problem:
        // (x y) ∧ (-x y) ∧ (x -y) ∧ (-x -y)
        let smt_input = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (declare-fun y () Int)

        (assert (>= x 0))
        (assert (<= x 1))
        (assert (>= y 0))
        (assert (<= y 1))

        (assert (>= (+      x       y)  1))
        (assert (>= (+ (- 1 x)      y)  1))
        (assert (>= (+      x  (- 1 y)) 1))
        (assert (>= (+ (- 1 x) (- 1 y)) 1))
        (check-sat)
        "#;

        let lra_solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());

        // Assert that the system is INFEASIBLE
        assert!(matches!(
            lira_solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));
    }

    /// Solve an UNSAT 3-SAT problem enoded using QF_LIA.
    ///
    /// (𝑥∨𝑦∨𝑧)∧(𝑥∨𝑦∨¬𝑧)∧(𝑥∨¬𝑦∨𝑧)∧(𝑥∨¬𝑦∨¬𝑧)∧(¬𝑥∨𝑦∨𝑧)∧(¬𝑥∨𝑦∨¬𝑧)∧(¬𝑥∨¬𝑦∨𝑧)∧(¬𝑥∨¬𝑦∨¬𝑧)
    ///
    /// A positive literal `x`` is encoded as an integer variable with coefficient 1 and bounds [0, 1].
    /// ¬x is encoded as the term (1-x). A disjunction of literals is encoded as the sum of the
    /// literals. Each encoded clause term is also required to be >= 1, meaning at least one literal
    /// is assigned true.
    ///
    /// For example, (𝑥∨𝑦∨𝑧) should be encoded as x + y + z, whereas the clause (𝑥∨¬𝑦∨𝑧) should be
    /// encoded as x + (1 - y) + z.
    ///
    /// The encoding in this unit test cost $2.61
    #[test]
    fn unsat_3_sat_branch_and_bound() {
        // This encodes the 3-SAT problem:
        // (𝑥∨𝑦∨𝑧)∧(𝑥∨𝑦∨¬𝑧)∧(𝑥∨¬𝑦∨𝑧)∧(𝑥∨¬𝑦∨¬𝑧)∧(¬𝑥∨𝑦∨𝑧)∧(¬𝑥∨𝑦∨¬𝑧)∧(¬𝑥∨¬𝑦∨𝑧)∧(¬𝑥∨¬𝑦∨¬𝑧)
        let smt_input = r#"
        (set-logic QF_LIA)
        (declare-fun x () Int)
        (declare-fun y () Int)
        (declare-fun z () Int)

        ; Bound all variables to [0, 1]
        (assert (>= x 0))
        (assert (<= x 1))
        (assert (>= y 0))
        (assert (<= y 1))
        (assert (>= z 0))
        (assert (<= z 1))

        ; Clause 1: (x ∨ y ∨ z) encoded as x + y + z >= 1
        (assert (>= (+ x y z) 1))

        ; Clause 2: (x ∨ y ∨ ¬z) encoded as x + y + (1-z) >= 1
        (assert (>= (+ x y (+ 1 (* (- 1) z))) 1))

        ; Clause 3: (x ∨ ¬y ∨ z) encoded as x + (1-y) + z >= 1
        (assert (>= (+ x (+ 1 (* (- 1) y)) z) 1))

        ; Clause 4: (x ∨ ¬y ∨ ¬z) encoded as x + (1-y) + (1-z) >= 1
        (assert (>= (+ x (+ 1 (* (- 1) y)) (+ 1 (* (- 1) z))) 1))

        ; Clause 5: (¬x ∨ y ∨ z) encoded as (1-x) + y + z >= 1
        (assert (>= (+ (+ 1 (* (- 1) x)) y z) 1))

        ; Clause 6: (¬x ∨ y ∨ ¬z) encoded as (1-x) + y + (1-z) >= 1
        (assert (>= (+ (+ 1 (* (- 1) x)) y (+ 1 (* (- 1) z))) 1))

        ; Clause 7: (¬x ∨ ¬y ∨ z) encoded as (1-x) + (1-y) + z >= 1
        (assert (>= (+ (+ 1 (* (- 1) x)) (+ 1 (* (- 1) y)) z) 1))

        ; Clause 8: (¬x ∨ ¬y ∨ ¬z) encoded as (1-x) + (1-y) + (1-z) >= 1
        (assert (>= (+ (+ 1 (* (- 1) x)) (+ 1 (* (- 1) y)) (+ 1 (* (- 1) z))) 1))
        "#;

        let lra_solver = smt_to_lra_solver(smt_input, &SolverConfig::default())
            .expect("Failed to create LRA solver");
        let mut lira_solver = LIRASolver::new(lra_solver, SolverConfig::default());

        // Assert that the system is INFEASIBLE
        assert!(matches!(
            lira_solver.solve().unwrap().decision,
            SolverDecision::INFEASIBLE(_)
        ));
    }

    /// Test from front page of https://lean-lang.org/ showcasing proof automation
    /// In the grind example, the first three hypotheses imply the fourth.
    ///
    /// https://www.desmos.com/calculator/y1wwdqoqle
    #[test]
    fn grind_test_playground() {
        let smt1 = r#"
        (declare-const x Int)
        (declare-const y Int)
        (assert (>= (+ (* 11 x) (* 13 y)) 27))
        (assert (<= (+ (* 11 x) (* 13 y)) 45))
        (assert (>= (- (* 7 x) (* 9 y)) (- 10)))
        (check-sat)
        "#;
        // first 3 constraints are sat
        let result = solve_smtlib(smt1, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)));

        // all 4 constraints are sat
        let smt2 = smt1.to_string() + "(assert (> (- (* 7 x) (* 9 y)) 4))";
        let result2 = solve_smtlib(&smt2, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result2, SolverDecisionApi::FEASIBLE(_)));

        // now prove validity
        // let r1 := 11x + 13 y
        //     r2 := 7x - 9y
        //     constraints C1...C4
        //
        // forall (x y: Int) C1 and C2 and C3 ==> C4
        // forall (x y: Int) -(C1 and C2 and C3) or C4
        // negate: exists (x y: Int) (C1 and ... and C3) and (-C4)
        let smt3 = smt1.to_string() + "(assert (not (> (- (* 7 x) (* 9 y)) 4)))";
        let result3 = solve_smtlib(&smt3, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result3, SolverDecisionApi::INFEASIBLE(_)));
    }

    /// Test from the Lean manual:
    /// https://lean-lang.org/doc/reference/latest/The--grind--tactic/Linear-Arithmetic-Solver/#grind-linarith
    /// Example 1
    #[test]
    fn grind_test_ref_manual_1() {
        let smt = r#"
        (declare-const a Int)
        (declare-const b Int)
        (assert (not (>= (+ (* 2 a) b) (+ b a a))))
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)),);
        if let SolverDecisionApi::INFEASIBLE(conflict) = result {
            assert_eq!(conflict.len(), 1);
        }
    }

    /// Test from the Lean manual:
    /// https://lean-lang.org/doc/reference/latest/The--grind--tactic/Linear-Arithmetic-Solver/#grind-linarith
    /// Example 2
    #[test]
    fn grind_test_ref_manual_2() {
        let smt = r#"
        (declare-const a Int)
        (declare-const b Int)
        (declare-const c Int)
        (assert (= a (+ b c)))
        (assert (<= (* 2 b) c))
        (assert (not (<= (* 2 a) (* 3 c))))
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)),);
        if let SolverDecisionApi::INFEASIBLE(conflict) = result {
            assert_eq!(conflict.len(), 3); // every subset of 2 assertions is feasible
        }
    }

    /// Test from the Lean manual:
    /// https://lean-lang.org/doc/reference/latest/The--grind--tactic/Linear-Arithmetic-Solver/#grind-linarith
    /// Example 3
    ///
    /// This example is infeasible over both ints and reals.
    #[test]
    fn grind_test_ref_manual_3() {
        let smt = r#"
        (declare-const a Real)
        (declare-const b Real)
        (declare-const c Real)
        (declare-const d Real)
        (declare-const e Real)

        ; assertions marked with 'x' are in conflict
        (assert (>= (+ (* 2.0 a) b) 0.0)) ; x
        (assert (>= b 0.0)) ; x
        (assert (>= c 0.0)) ; x
        (assert (>= d 0.0)) ; x
        (assert (>= e 0.0)) ; x
        (assert (>= a (* 3.0 c)))
        (assert (>= c (* 6.0 e)))
        (assert (>= (- d (* 5.0 e)) 0.0))
        (assert (< (+ a b (* 3.0 c) d (* 2.0 e)) 0.0))  ; x
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)),);
        if let SolverDecisionApi::INFEASIBLE(conflict) = result {
            assert_eq!(conflict.len(), 6);
        }

        // Check that the conflict set is actually conflicting.
        // This test may be brittle if conflict computation is not stable.
        let smt_conflict = r#"
        (declare-const a Real)
        (declare-const b Real)
        (declare-const c Real)
        (declare-const d Real)
        (declare-const e Real)

        ; assertions marked with 'x' are in conflict
        (assert (>= (+ (* 2.0 a) b) 0.0)) ; x
        (assert (>= b 0.0)) ; x
        (assert (>= c 0.0)) ; x
        (assert (>= d 0.0)) ; x
        (assert (>= e 0.0)) ; x
        (assert (< (+ a b (* 3.0 c) d (* 2.0 e)) 0.0))  ; x
        (check-sat)
        "#;
        let result = solve_smtlib(smt_conflict, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)),);

        // Sanity check that the conflict is minimal; not a proof of such, just
        // removing one constraint b >= 0 and showing feasibility.
        let smt_conflict = r#"
        (declare-const a Real)
        (declare-const b Real)
        (declare-const c Real)
        (declare-const d Real)
        (declare-const e Real)

        ; assertions marked with 'x' are in conflict
        (assert (>= (+ (* 2.0 a) b) 0.0)) ; x
        (assert (>= c 0.0)) ; x
        (assert (>= d 0.0)) ; x
        (assert (>= e 0.0)) ; x
        (assert (< (+ a b (* 3.0 c) d (* 2.0 e)) 0.0))  ; x
        (check-sat)
        "#;
        let result = solve_smtlib(smt_conflict, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)),);
    }

    // Regression test from https://github.com/yaspar-org/Sundance-SMT/issues/33
    //
    //  b <  0       {       b < 0
    // -b <= 1  -->  { -1 <= b
    // -b <  1       { -1 <  b
    //
    // The first and 3rd constraints are mutually UNSAT.
    #[test]
    fn regresssion_issue_33() {
        let smt = r#"
        (declare-const b Int)
        (assert (< b 0))
        (assert (<= (- b) 1))
        (assert (< (- b) 1))
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::INFEASIBLE(_)),);
        if let SolverDecisionApi::INFEASIBLE(conflict) = result {
            assert_eq!(conflict.len(), 2);
            // The terms printed here are correct by inspection
            // println!("{conflict:#?}");
        }
    }

    #[test]
    fn regression_issue_30() {
        let smt = r#"
        (set-logic QF_LRA)
        (declare-const x Real)
        (assert (= (* 2 x) 3))
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(matches!(result, SolverDecisionApi::FEASIBLE(_)),);
        if let SolverDecisionApi::FEASIBLE(assg) = result {
            let (_, val) = assg.iter().next().unwrap();
            assert_eq!(Rational::from(2) * val, Rational::from(3));
        }
    }

    /// Branch-and-bound branches on the same variable more than once along a path here. The
    /// conflict of an inner branch then depends on the bound asserted by an outer branch on
    /// that variable, which must survive the resolution at the inner node. Resolving the
    /// variable away entirely made the search prune a subtree containing the model and report
    /// INFEASIBLE.
    ///
    /// This is a linearization of the following, with `q = (div x1 3)` and `r = (div x0 3)`:
    /// ```smt2
    /// (assert (< (+ 4 (mod x0 3)) (+ 4 (* 2 (div x1 3)))))
    /// (assert (not (< (+ (- 2) (* (- 3) x2) (* 2 x1)) (+ 2 (* (- 1) x1) x2))))
    /// ```
    /// It is satisfied by `x0 = 0, x1 = 3, x2 = 0`.
    #[test]
    fn regression_repeated_branch_on_same_var() {
        let smt = r#"
        (set-logic QF_LIA)
        (declare-const x0 Int)
        (declare-const x1 Int)
        (declare-const x2 Int)
        (declare-const q Int)
        (declare-const r Int)
        (assert (<= (- 3) x0))
        (assert (<= x0 3))
        (assert (<= (- 3) x1))
        (assert (<= x1 3))
        (assert (<= (- 3) x2))
        (assert (<= x2 3))
        (assert (<= (* 3 q) x1))
        (assert (<= x1 (+ (* 3 q) 2)))
        (assert (<= (* 3 r) x0))
        (assert (<= x0 (+ (* 3 r) 2)))
        (assert (< (- x0 (* 3 r)) (* 2 q)))
        (assert (>= (- (* 3 x1) (* 4 x2)) 4))
        (check-sat)
        "#;
        let result = solve_smtlib(smt, &SolverConfig::default()).expect("solver failed");
        assert!(
            matches!(result, SolverDecisionApi::FEASIBLE(_)),
            "{result:?}"
        );
    }
}
