// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

//! Main CDCL decision loop
use crate::arithmetic::incremental_solver::IncrementalArithSolver;
use crate::arithmetic::incremental_solver::lira::LiraIncrementalState;
use crate::arithmetic::incremental_solver::translation::ArithTranslator;
use crate::arithmetic::lia::config::SolverConfig;
use crate::arithmetic::lp::ArithSolver;
use crate::cadical_propagator::{CustomExternalPropagator, EagerQiMode, ObservedSink};
use crate::config::SatBackend;
use crate::debug_println;
use crate::egraphs::EgraphTrait;
use crate::proof::{SMTProofTracer, Theory};
use crate::solver_state::SolverState;
use crate::stats::SolverStats;
use crate::utils::DeterministicHashSet;
use cadical_sys::{CaDiCal, Status, Terminator};
use std::cell::RefCell;
use std::collections::HashMap;
use std::io::Write;
use std::path::PathBuf;
use std::rc::Rc;
use std::time::Instant;
use yaspar_ir::ast::{FunctionMeta, Sig, SortDef, Str};

struct DeadlineTerminator {
    deadline: Instant,
}

impl Terminator for DeadlineTerminator {
    fn terminated(&mut self) -> bool {
        Instant::now() >= self.deadline
    }
}

#[cfg(feature = "minisat")]
impl sat_interface::Terminator for DeadlineTerminator {
    fn terminated(&mut self) -> bool {
        Terminator::terminated(self)
    }
}

/// The propositional search engine selected by `--sat-backend`
enum Backend {
    Cadical(Box<CaDiCal>),
    #[cfg(feature = "minisat")]
    Minisat(Box<sat_interface::minisat::MiniSat>),
}

/// Main CDCL decision loop
///
/// todo: reduce the number of arguments
#[allow(clippy::too_many_arguments)]
pub fn cdcl_decision_procedure(
    solver_state: &mut SolverState,
    clauses: Vec<Vec<i32>>,
    boolean_dt_constraints: Vec<Vec<i32>>,
    proof_file: Option<PathBuf>,
    partial_proof_file: Option<PathBuf>,
    trail_file: Option<PathBuf>,
    sorts: HashMap<Str, SortDef>,
    symbol_table: HashMap<Str, Vec<(Sig, FunctionMeta)>>,
    arithmetic: ArithSolver,
    timeout: u64,
    sat_backend: SatBackend,
    elevate: i32,
    max_arith_conflicts_per_round: usize,
    batch_cap: usize,
    eager_qi: i32,
) -> (Status, SolverStats) {
    // Create proof tracker for real-time proof tracking wrapped in Rc<RefCell<>>
    // todo: for right now always have hid_quantifiers to be true, need to change this
    let proof_tracer = Rc::new(RefCell::new(SMTProofTracer::new(sorts, symbol_table)));

    // A requested proof is trimmed to the clauses the refutation uses, which needs CaDiCaL's
    // clause ids and antecedents
    if proof_file.is_some() {
        proof_tracer.borrow_mut().track_core();
    }

    let mut solver = match sat_backend {
        SatBackend::Cadical => {
            // Boxed so the propagator's pointer stays valid when `solver` moves.
            let mut cadical = Box::new(CaDiCal::new());
            assert!(
                cadical.set("elevate".to_string(), elevate),
                "CaDiCaL option 'elevate' is unavailable; Sundance requires CaDiCaL >= 3.0.1 for lazy quantifier instantiation"
            );
            // Connect the proof tracer (must be done in CONFIGURING state)
            cadical.connect_proof_tracer1(&mut *proof_tracer.borrow_mut(), true); // true for antecedents
            Backend::Cadical(cadical)
        }
        SatBackend::Minisat => {
            assert!(
                proof_file.is_none() && partial_proof_file.is_none(),
                "MiniSat currently has no proof tracer; --proof/--partial-proof require --sat-backend cadical"
            );
            #[cfg(feature = "minisat")]
            {
                let mut minisat = Box::new(sat_interface::minisat::MiniSat::new());
                assert!(
                    minisat.set("phase", 1),
                    "MiniSat option 'phase' is unavailable"
                );
                Backend::Minisat(minisat)
            }
            #[cfg(not(feature = "minisat"))]
            {
                panic!("--sat-backend minisat requires building with `--features minisat`")
            }
        }
    };

    let deadline = (timeout > 0).then(|| Instant::now() + std::time::Duration::from_secs(timeout));
    let mut terminator = deadline.map(|deadline| DeadlineTerminator { deadline });
    if let Some(t) = terminator.as_mut() {
        match &mut solver {
            Backend::Cadical(cadical) => cadical.connect_terminator(t),
            #[cfg(feature = "minisat")]
            Backend::Minisat(minisat) => minisat.connect_terminator(t),
        }
    }
    let observed_sink = match &mut solver {
        Backend::Cadical(cadical) => ObservedSink::Cadical(&mut **cadical as *mut CaDiCal),
        #[cfg(feature = "minisat")]
        Backend::Minisat(minisat) => {
            ObservedSink::Minisat(&mut **minisat as *mut sat_interface::minisat::MiniSat)
        }
    };

    // The internal solvers' branch-and-bound runs inside a CaDiCaL callback, where the
    // terminator is not polled, so it checks the deadline itself.
    let lia_config = SolverConfig {
        deadline,
        ..SolverConfig::default()
    };
    let incremental_backend: Option<Box<dyn IncrementalArithSolver>> = match arithmetic {
        ArithSolver::InternalIncremental => Some(Box::new(LiraIncrementalState::with_config(
            lia_config.clone(),
        ))),
        #[cfg(feature = "z3-solver")]
        ArithSolver::Z3Incremental => Some(Box::new(
            crate::arithmetic::incremental_solver::z3::Z3IncrementalState::new(),
        )),
        _ => None,
    };
    solver_state
        .egraph
        .incremental_arithmetic(incremental_backend.is_some());
    let arith_translator = incremental_backend.map(ArithTranslator::new);

    let mut propagator = CustomExternalPropagator {
        decision_level: 0,
        solver_state,
        disequalities: RefCell::new(vec![]),
        fixed_literals: DeterministicHashSet::default(),
        proof_tracer: Rc::clone(&proof_tracer),
        assignments: vec![0, 0],
        observed_sink,
        arithmetic,
        stats: SolverStats::new(),
        pending: None,
        eager_qi: EagerQiMode::new(eager_qi),
        materializing_quantifiers: false,
        max_arith_conflicts_per_round,
        last_observed_var: 1,
        batch_cap,
        arith: arith_translator,
        lia_config,
        arith_incomplete: false,
        trail_writer: trail_file
            .as_ref()
            .and_then(|p| match std::fs::File::create(p) {
                Ok(f) => Some(std::io::BufWriter::new(f)),
                Err(e) => {
                    debug_println!(2, 0, "Failed to open trail log {}: {}", p.display(), e);
                    None
                }
            }),
        trail_atoms: std::collections::HashMap::new(),
    };

    match &mut solver {
        Backend::Cadical(cadical) => cadical.connect_external_propagator(&mut propagator),
        #[cfg(feature = "minisat")]
        Backend::Minisat(minisat) => minisat.connect_external_propagator(&mut propagator),
    }
    // note: not using a fixed listener anymore
    // solver.connect_fixed_listener(&mut propagator);

    debug_println!(2, 0, "CDCL: Starting CDCL solver");
    debug_println!(1, 1, "Adding {} clauses to solver", clauses.len());

    // Add all clauses to the solver
    for (i, clause) in clauses.iter().enumerate() {
        debug_println!(11, 2, "Adding clause #{}: {:?}", i + 1, clause);
        add_clause_to_proof_and_solver(clause, &mut solver, &proof_tracer, None);
    }

    // adding this into disequalities instead so that it appears as a theory lemma
    for clause in &boolean_dt_constraints {
        add_clause_to_proof_and_solver(clause, &mut solver, &proof_tracer, Some(Theory::Datatypes));
    }

    // Observe all known CNF variables at startup
    propagator.sync_new_vars();

    debug_println!(2, 1, "All clauses added, starting solver");

    for clause in &boolean_dt_constraints {
        match clause.len() {
            0 | 1 => {}
            2 => propagator.stats.binary_clauses += 1,
            _ => propagator.stats.clauses += 1,
        }
    }

    let result = match &mut solver {
        Backend::Cadical(cadical) => {
            let result = cadical.solve();
            // Disconnect the proof tracer before dropping the propagator
            cadical.disconnect_proof_tracer1();
            result
        }
        #[cfg(feature = "minisat")]
        Backend::Minisat(minisat) => {
            use sat_interface::minisat::Status as MiniSatStatus;
            let result = match minisat.solve() {
                MiniSatStatus::Satisfiable => Status::SATISFIABLE,
                MiniSatStatus::Unsatisfiable => Status::UNSATISFIABLE,
                MiniSatStatus::Unknown => Status::UNKNOWN,
            };
            minisat.disconnect_external_propagator();
            minisat.disconnect_terminator();
            result
        }
    };

    // An accepted model is not known to be a model of the input if an arithmetic check gave up
    // on it, or if the arithmetic solver is inexact (an opaque term).
    let result = if result == Status::SATISFIABLE
        && (propagator.arith_incomplete || propagator.arith.as_ref().is_some_and(|a| !a.is_exact()))
    {
        Status::UNKNOWN
    } else {
        result
    };

    // Write the proof after all borrows are released. `--proof` writes it on unsat only, trimmed
    // to the refutation; `--partial-proof` writes everything recorded, for any result.
    if let Some(p) = proof_file
        && result == Status::UNSATISFIABLE
    {
        if let Err(e) = write_proof_file(&p, |w| proof_tracer.borrow().write_edrat(w, true)) {
            debug_println!(
                2,
                0,
                "Failed to write eDRAT proof to {}: {}",
                p.display(),
                e
            );
        } else {
            debug_println!(2, 0, "eDRAT proof written to: {}", p.display());
        }
    }

    if let Some(p) = partial_proof_file {
        write_partial_proof(&p, result, &proof_tracer.borrow());
    }

    // Trails were streamed during the solve; append the now-complete atom map.
    if trail_file.is_some() {
        propagator.finish_trail_log();
        debug_println!(2, 0, "trail log written");
    }

    // Harvest stats from solver_state, egraph, and proof tracer
    propagator.sync_external_stats();
    propagator.stats.finish();
    (result, propagator.stats)
}

/// Creates `path` and streams the proof into it through `write`.
fn write_proof_file(
    path: &std::path::Path,
    write: impl FnOnce(&mut std::io::BufWriter<std::fs::File>) -> std::io::Result<()>,
) -> std::io::Result<()> {
    let mut out = std::io::BufWriter::new(std::fs::File::create(path)?);
    write(&mut out)?;
    out.flush()
}

/// Dump the eDRAT proof forest for any result: complete on unsat, else a prefix
/// with no final empty clause. A leading `;` comment records which case it is.
/// Header status: unsat -> unsat, sat -> unknown, unknown (cadical) ->
/// timeout/interrupt.
fn write_partial_proof(path: &std::path::Path, result: Status, proof_tracer: &SMTProofTracer) {
    let complete = result == Status::UNSATISFIABLE;
    let status = match result {
        Status::UNSATISFIABLE => "unsat",
        Status::SATISFIABLE => "unknown",
        Status::UNKNOWN => "timeout/interrupt",
    };
    let header = if complete {
        "; COMPLETE eDRAT proof (result: unsat): a checkable refutation.\n".to_string()
    } else {
        format!(
            "; PARTIAL eDRAT proof (result: {status}): every step derived so far,\n\
             ; but NO final empty clause -- a prefix, not a checkable refutation.\n"
        )
    };
    if let Err(e) = write_proof_file(path, |w| {
        w.write_all(header.as_bytes())?;
        proof_tracer.write_edrat(w, false)
    }) {
        debug_println!(
            2,
            0,
            "Failed to write partial proof to {}: {}",
            path.display(),
            e
        );
    } else {
        debug_println!(
            2,
            0,
            "{} proof forest written to: {}",
            if complete { "Complete" } else { "Partial" },
            path.display()
        );
    }
}

/// Records a clause before the SAT solver can synchronously simplify or delete it.
/// A missing `theory` denotes an original CNF clause.
fn add_clause_to_proof_and_solver(
    clause: &[i32],
    solver: &mut Backend,
    proof_tracer: &RefCell<SMTProofTracer>,
    theory: Option<Theory>,
) {
    {
        let mut proof_tracer = proof_tracer.borrow_mut();
        if let Some(theory) = theory {
            proof_tracer.add_theory_clause(clause, theory);
        } else {
            proof_tracer.add_original_clause(clause);
        }
        proof_tracer.register_clause_for_cadical_callback(clause);
    }

    match solver {
        Backend::Cadical(cadical) => cadical.clause6(clause), // TODO `clause1()`, `clause2()`, etc. might be more efficient
        #[cfg(feature = "minisat")]
        Backend::Minisat(minisat) => minisat.add_clause(clause),
    }
}
